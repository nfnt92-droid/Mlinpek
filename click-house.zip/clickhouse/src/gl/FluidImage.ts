import { gsap } from '../lib/gsap'
import { pointer, damp } from '../lib/pointer'

const VERT = `
attribute vec2 aPos;
varying vec2 vUv;
void main(){ vUv = aPos * .5 + .5; gl_Position = vec4(aPos, 0., 1.); }`

// Cursor-driven lens + velocity smear + chromatic split, with an idle "breath".
const FRAG = `
precision mediump float;
uniform sampler2D uTex;
uniform vec2 uRes, uImg, uMouse, uVel;
uniform float uTime, uHover, uWave, uZoom, uTop;
varying vec2 vUv;

vec2 cover(vec2 uv){
  float rs = uRes.x / uRes.y, ri = uImg.x / uImg.y;
  vec2 s = rs < ri ? vec2(rs / ri, 1.) : vec2(1., ri / rs);
  vec2 c = (uv - .5) * s + .5;
  c.y = mix(c.y, (uv.y - 1.) * s.y + 1., uTop);
  c.x = mix(c.x, uv.x * s.x, uTop);
  return c;
}
void main(){
  vec2 uv = vUv;
  uv = (uv - .5) * (1. - uZoom) + .5;
  vec2 d = uv - uMouse;
  d.x *= uRes.x / uRes.y;
  float dist = length(d);
  float f = smoothstep(.55, 0., dist) * uHover;
  float vel = length(uVel);
  // lens bulge
  uv -= d * f * .09;
  // smear along velocity
  uv -= uVel * f * 1.4;
  // idle breathing
  uv.y += sin(uv.x * 5. + uTime * .9) * .006 * uWave;
  uv.x += cos(uv.y * 4. + uTime * .7) * .006 * uWave;
  vec2 off = uVel * (f * 1.2 + .15) + vec2(.0012) * f;
  vec2 c = cover(uv);
  float r = texture2D(uTex, cover(uv + off)).r;
  float g = texture2D(uTex, c).g;
  float b = texture2D(uTex, cover(uv - off)).b;
  vec3 col = vec3(r, g, b);
  col += f * vel * 1.2;
  gl_FragColor = vec4(col, 1.);
}`

type Opts = { mode: 'hover' | 'reel'; zoom?: number; alignTop?: boolean }

export class FluidImage {
  private gl: WebGLRenderingContext
  private u: Record<string, WebGLUniformLocation | null> = {}
  private img = new Image()
  private ready = false
  private visible = true
  private state = { mx: 0.5, my: 0.5, vx: 0, vy: 0, hover: 0, wave: 0, zoom: 0 }
  private targetHover = 0
  private ro: ResizeObserver
  private io: IntersectionObserver
  private canvas: HTMLCanvasElement
  private opts: Opts
  private lx = 0.5
  private ly = 0.5
  private t0 = performance.now()

  static supported() {
    try {
      const c = document.createElement('canvas')
      return !!(c.getContext('webgl') || c.getContext('experimental-webgl'))
    } catch {
      return false
    }
  }

  constructor(canvas: HTMLCanvasElement, host: HTMLElement, src: string, opts: Opts) {
    this.canvas = canvas
    this.opts = opts
    const gl = canvas.getContext('webgl', { antialias: false, alpha: false, powerPreference: 'high-performance' })
    if (!gl) throw new Error('no webgl')
    this.gl = gl
    this.compile()
    this.state.wave = opts.mode === 'reel' ? 1 : 0.25
    this.state.zoom = opts.zoom ?? 0
    this.img.crossOrigin = 'anonymous'
    this.img.onload = () => {
      this.upload()
      this.ready = true
      host.classList.add('gl-ready')
    }
    this.img.src = src
    this.ro = new ResizeObserver(() => this.resize())
    this.ro.observe(canvas)
    this.io = new IntersectionObserver(([e]) => (this.visible = e.isIntersecting), { rootMargin: '100px' })
    this.io.observe(host)
    this.resize()
    gsap.ticker.add(this.tick)
  }

  setHover(v: number) {
    this.targetHover = v
  }
  setZoom(v: number) {
    this.state.zoom = v
  }

  private compile() {
    const gl = this.gl
    const sh = (type: number, src: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, src)
      gl.compileShader(s)
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) console.warn(gl.getShaderInfoLog(s))
      return s
    }
    const p = gl.createProgram()!
    gl.attachShader(p, sh(gl.VERTEX_SHADER, VERT))
    gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FRAG))
    gl.linkProgram(p)
    gl.useProgram(p)
    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW)
    const loc = gl.getAttribLocation(p, 'aPos')
    gl.enableVertexAttribArray(loc)
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0)
    for (const n of ['uTex', 'uRes', 'uImg', 'uMouse', 'uVel', 'uTime', 'uHover', 'uWave', 'uZoom', 'uTop']) this.u[n] = gl.getUniformLocation(p, n)
  }

  private upload() {
    const gl = this.gl
    const tex = gl.createTexture()
    gl.bindTexture(gl.TEXTURE_2D, tex)
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true)
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, this.img)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
    gl.uniform1i(this.u.uTex, 0)
    gl.uniform2f(this.u.uImg, this.img.naturalWidth, this.img.naturalHeight)
  }

  private resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.75)
    const w = Math.max(1, Math.round(this.canvas.clientWidth * dpr))
    const h = Math.max(1, Math.round(this.canvas.clientHeight * dpr))
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w
      this.canvas.height = h
      this.gl.viewport(0, 0, w, h)
    }
    this.gl.uniform2f(this.u.uRes, w, h)
  }

  private tick = (_t: number, dt: number) => {
    if (!this.ready || !this.visible) return
    const gl = this.gl
    const s = this.state
    const r = this.canvas.getBoundingClientRect()
    const mx = (pointer.x - r.left) / r.width
    const my = 1 - (pointer.y - r.top) / r.height
    if (this.opts.mode === 'reel') this.targetHover = pointer.active ? 1 : 0
    s.hover += (this.targetHover - s.hover) * damp(0.06, dt)
    s.mx += (mx - s.mx) * damp(0.12, dt)
    s.my += (my - s.my) * damp(0.12, dt)
    const vx = (s.mx - this.lx) * (r.width / r.height)
    const vy = s.my - this.ly
    this.lx = s.mx
    this.ly = s.my
    s.vx += (gsap.utils.clamp(-0.06, 0.06, vx) - s.vx) * damp(0.2, dt)
    s.vy += (gsap.utils.clamp(-0.06, 0.06, vy) - s.vy) * damp(0.2, dt)
    gl.uniform2f(this.u.uMouse, s.mx, s.my)
    gl.uniform2f(this.u.uVel, s.vx, s.vy)
    gl.uniform1f(this.u.uTime, (performance.now() - this.t0) / 1000)
    gl.uniform1f(this.u.uHover, s.hover)
    gl.uniform1f(this.u.uWave, s.wave)
    gl.uniform1f(this.u.uZoom, s.zoom)
    gl.uniform1f(this.u.uTop, this.opts.alignTop ? 1 : 0)
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
  }

  destroy() {
    gsap.ticker.remove(this.tick)
    this.ro.disconnect()
    this.io.disconnect()
    this.gl.getExtension('WEBGL_lose_context')?.loseContext()
  }
}
