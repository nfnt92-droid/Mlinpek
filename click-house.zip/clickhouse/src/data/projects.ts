/**
 * Click House projects — edit everything here.
 *
 * Rules:
 *  - Never invent a URL. Leave `url: ''` until you have the real address;
 *    the card then shows "Link coming soon" and is not clickable.
 *  - `status: 'concept'` = speculative / unsolicited design, labelled "Concept"
 *    everywhere. Switch to 'client' only for delivered, commissioned work.
 *  - `industry` and `services` render only when filled in.
 *  - `featured` sets the homepage Selected Work order (1–4). Leave null to
 *    show a project on /work only.
 *  - `preview`: optional .webp screenshot in /public (e.g. 'img/work/mlinpek.webp').
 *    Used as the static preview, and as the fallback when a live embed is off.
 *  - `embed`: try a live, lazy-loaded iframe preview of `url`. Some sites block
 *    embedding (X-Frame-Options / CSP) — if a card shows a blank or error frame,
 *    set `embed: false` and add a `preview` screenshot instead.
 */
export type ProjectStatus = 'client' | 'concept'

export type Project = {
  slug: string
  title: string
  url: string
  status: ProjectStatus
  industry: string
  services: string[]
  year: string
  featured: number | null
  /** card palette — each project gets its own, within the house system */
  color: string
  ink: string
  preview?: string
  embed: boolean
  /** short one-liner for the case page; leave empty to hide */
  summary: string
  /** case page "Challenge" paragraph; leave empty to hide */
  brief: string
  /** image used on /work hover + "next project" (path without .webp; needs a -sm twin) */
  image: string
  /** case-study screenshots (.webp in /public) */
  shots?: { desktop: string; mobile: string; section: string }

  // compatibility aliases used by existing pages
  client: string
  tags: string[]
}

type Input = Omit<Project, 'client' | 'tags'>

const define = (p: Input): Project => ({ ...p, client: p.title, tags: p.services })

export const projects: Project[] = [
  define({
    slug: 'mlinpek',
    title: 'Mlinpek',
    url: 'https://spiffy-malasada-007fc6.netlify.app/',
    status: 'concept',
    industry: 'Industrial bakery',
    services: [], // TODO: e.g. ['Web design', 'Development']
    year: '',
    featured: 1,
    color: '#d9ccb0',
    ink: '#2a2118',
    embed: true,
    preview: 'img/work/mlinpek.webp',
    summary: '',
    brief: '',
    image: 'img/work/mlinpek-desktop',
    shots: { desktop: 'img/work/mlinpek-desktop.webp', mobile: 'img/work/mlinpek-mobile.webp', section: 'img/work/mlinpek-section.webp' },
  }),
  define({
    slug: 'kalvarija-kop',
    title: 'Kalvarija Kop',
    url: 'https://kalvarijacopp.netlify.app/',
    status: 'concept',
    industry: 'Dolomite quarry',
    services: [],
    year: '',
    featured: 2,
    color: '#cfd0cc',
    ink: '#1d1f22',
    embed: true,
    preview: 'img/work/kalvarija-kop.webp',
    summary: '',
    brief: '',
    image: 'img/work/kalvarija-kop-desktop',
    shots: { desktop: 'img/work/kalvarija-kop-desktop.webp', mobile: 'img/work/kalvarija-kop-mobile.webp', section: 'img/work/kalvarija-kop-section.webp' },
  }),
  define({
    slug: 'tecta',
    title: 'Tecta',
    url: 'https://dapper-squirrel-36de48.netlify.app/',
    status: 'concept',
    industry: 'Construction',
    services: [],
    year: '',
    featured: 3,
    color: '#2f3a44',
    ink: '#e9ecee',
    embed: false, // site sends X-Frame-Options: SAMEORIGIN → screenshot instead
    preview: 'img/work/tecta.webp',
    summary: '',
    brief: '',
    image: 'img/work/tecta-desktop',
    shots: { desktop: 'img/work/tecta-desktop.webp', mobile: 'img/work/tecta-mobile.webp', section: 'img/work/tecta-section.webp' },
  }),
  define({
    slug: 'kadg',
    title: 'K.A.D.G',
    url: 'https://kadg.ba/',
    status: 'concept',
    industry: 'Steel trade',
    services: [],
    year: '',
    featured: 4,
    color: '#4a1d27',
    ink: '#f1e8e2',
    embed: true,
    preview: 'img/work/kadg.webp',
    summary: '',
    brief: '',
    image: 'img/work/kadg-desktop',
    shots: { desktop: 'img/work/kadg-desktop.webp', mobile: 'img/work/kadg-mobile.webp', section: 'img/work/kadg-section.webp' },
  }),
]

export const featuredProjects = projects
  .filter((p) => p.featured !== null)
  .sort((a, b) => (a.featured ?? 0) - (b.featured ?? 0))

export const getProject = (slug?: string) => projects.find((p) => p.slug === slug)
export const nextProject = (slug: string) => {
  const i = projects.findIndex((p) => p.slug === slug)
  return projects[(i + 1) % projects.length]
}

export const domainOf = (url: string) => {
  try {
    return new URL(url).host.replace(/^www\./, '')
  } catch {
    return ''
  }
}
