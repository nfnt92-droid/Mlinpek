import { Routes, Route, useLocation } from 'react-router-dom'
import { TransitionProvider } from './components/TransitionProvider'
import Nav from './components/Nav'
import Preloader from './components/Preloader'
import Home from './pages/Home'
import Work from './pages/Work'
import Project from './pages/Project'
import Studio from './pages/Studio'
import Contact from './pages/Contact'

function RoutedPages() {
  const location = useLocation()
  return (
    <Routes location={location} key={location.pathname}>
      <Route path="/" element={<Home />} />
      <Route path="/work" element={<Work />} />
      <Route path="/work/:slug" element={<Project />} />
      <Route path="/studio" element={<Studio />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="*" element={<Home />} />
    </Routes>
  )
}

export default function App() {
  return (
    <TransitionProvider>
      <Preloader />
      <Nav />
      <RoutedPages />
      <div className="grain" aria-hidden />
    </TransitionProvider>
  )
}
