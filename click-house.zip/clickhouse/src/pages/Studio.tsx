import { useRef } from 'react'
import { gsap } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { onPageEnter } from '../lib/transition'
import { asset } from '../lib/env'
import Reveal from '../components/Reveal'
import ProximityType from '../components/ProximityType'
import Marquee from '../components/Marquee'
import Footer from '../components/Footer'
import GLImage from '../components/GLImage'

const PRINCIPLES = [
  ['Motion is meaning', 'Animation is never decoration. If it moves, it tells you something — where you are, what changed, what matters.'],
  ['Feel before features', 'We prototype the sensation of a product first. Responsiveness is a brand value.'],
  ['Small team, full craft', 'Strategy, design and development sit at one table. Nothing gets lost in hand-offs.'],
  ['Fast is a feeling too', 'Every effect is budgeted. Smooth on a flagship laptop, respectful on a phone.'],
]

const CAPS = {
  Brand: ['Strategy', 'Naming', 'Identity systems', 'Guidelines'],
  Digital: ['Websites', 'E-commerce', 'Web apps', 'CMS'],
  Motion: ['Interaction design', 'WebGL', '3D & shaders', 'Product animation'],
}

export default function Studio() {
  const ref = useRef<HTMLElement>(null)
  useGsap(
    () => {
      gsap.set('.studio-hero .px-char', { yPercent: 115 })
      const off = onPageEnter(() => gsap.to('.studio-hero .px-char', { yPercent: 0, stagger: 0.03, duration: 1.4, delay: 0.3 }))
      // wide image expands from a card to full-bleed as it crosses the viewport
      gsap.fromTo(
        '.studio-wide',
        { clipPath: 'inset(0% 22% 0% 22% round 20px)' },
        { clipPath: 'inset(0% 0% 0% 0% round 0px)', ease: 'none', scrollTrigger: { trigger: '.studio-wide', start: 'top 85%', end: 'center center', scrub: true } },
      )
      gsap.utils.toArray<HTMLElement>('.principle').forEach((el) => {
        gsap.from(el.querySelector('.principle__line'), { scaleX: 0, transformOrigin: '0 50%', duration: 1.4, scrollTrigger: { trigger: el, start: 'top 88%' } })
        gsap.from(el.querySelectorAll('.principle__n, .principle__t, .principle__d'), { y: 40, opacity: 0, stagger: 0.08, duration: 1.2, scrollTrigger: { trigger: el, start: 'top 85%' } })
      })
      gsap.from('.caps__col li', { yPercent: 100, opacity: 0, stagger: 0.03, duration: 1, scrollTrigger: { trigger: '.caps', start: 'top 80%' } })
      return off as unknown as () => void
    },
    ref,
  )
  return (
    <main className="page page--studio" ref={ref}>
      <section className="studio-hero page-hero">
        <span className="eyebrow">(Studio)</span>
        <h1 className="studio-hero__title">
          <ProximityType text="We make" radius={0.25} />
          <br />
          <ProximityType text="screens" radius={0.25} /> <em className="serif">breathe.</em>
        </h1>
      </section>
      <section className="section studio-intro">
        <Reveal as="p" className="studio-intro__text">
          Click House is a creative digital studio for brands that want to be felt, not just seen. We design identities and build websites where motion and interaction carry the story.
        </Reveal>
        <Reveal as="p" className="lede studio-intro__side" delay={0.2}>
          Independent and senior-led. We take on a handful of projects at a time so every detail gets the attention it deserves.
        </Reveal>
      </section>
      <section className="studio-wide" data-cursor="hide">
        <GLImage src="img/studio" alt="Click House studio texture" mode="reel" />
        <div className="studio-wide__label">
          <span className="eyebrow">Our medium</span>
          <span className="studio-wide__big">Interaction</span>
        </div>
      </section>
      <section className="section principles">
        <header className="section-head">
          <span className="eyebrow">(Principles)</span>
          <Reveal as="h2" className="section-title" type="chars">
            What we <em className="serif">believe</em>
          </Reveal>
        </header>
        {PRINCIPLES.map(([t, d], i) => (
          <div className="principle" key={t}>
            <span className="principle__line" />
            <span className="principle__n">0{i + 1}</span>
            <h3 className="principle__t">{t}</h3>
            <p className="principle__d">{d}</p>
          </div>
        ))}
      </section>
      <Marquee items={['Brand', 'Digital', 'Motion', 'Craft']} className="marquee--big" />
      <section className="section caps">
        <span className="eyebrow">(Capabilities)</span>
        <div className="caps__grid">
          {Object.entries(CAPS).map(([k, v]) => (
            <div className="caps__col" key={k}>
              <h3>{k}</h3>
              <ul>
                {v.map((x) => (
                  <li key={x}>{x}</li>
                ))}
              </ul>
            </div>
          ))}
          <div className="caps__col caps__img">
            <img src={asset('img/verde-sm.webp')} alt="" />
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
