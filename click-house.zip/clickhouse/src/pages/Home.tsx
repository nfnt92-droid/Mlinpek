import Hero from '../sections/Hero'
import Manifesto from '../sections/Manifesto'
import SelectedWork from '../sections/SelectedWork'
import Services from '../sections/Services'
import Process from '../sections/Process'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <main className="page page--home">
      <Hero />
      <Manifesto />
      <SelectedWork />
      <Services />
      <Process />
      <Footer />
    </main>
  )
}
