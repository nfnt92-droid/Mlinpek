import { useRef } from 'react'
import { useParams } from 'react-router-dom'
import { getProject, nextProject, projects } from '../data/projects'
import { gsap, SplitText } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { onPageEnter } from '../lib/transition'
import { asset } from '../lib/env'
import GLImage, { type GLImageHandle } from '../components/GLImage'
import { PreviewBar } from '../components/ProjectPreview'
import ParallaxMedia from '../components/ParallaxMedia'
import Reveal from '../components/Reveal'
import { useTransitionNav } from '../components/TransitionProvider'

export default function Project() {
  const { slug } = useParams()
  const p = getProject(slug) ?? projects[0]
  const next = nextProject(p.slug)
  const ref = useRef<HTMLElement>(null)
  const { go } = useTransitionNav()
  const coverGl = useRef<GLImageHandle>(null)

  useGsap(
    () => {
      const root = ref.current!
      const title = root.querySelector<HTMLElement>('.case-hero__title')!
      const split = SplitText.create(title, { type: 'chars', mask: 'chars' })
      gsap.set(split.chars, { yPercent: 110 })
      gsap.set('.case-hero__meta > *', { opacity: 0, y: 20 })
      gsap.set('.case-cover', { clipPath: 'inset(30% 12% 0% 12%)' })
      gsap.set('.case-cover .gl-image', { scale: 1.3 })
      const off = onPageEnter(() => {
        const tl = gsap.timeline({ delay: 0.3 })
        tl.to(split.chars, { yPercent: 0, stagger: 0.04, duration: 1.4 })
          .to('.case-hero__meta > *', { opacity: 1, y: 0, stagger: 0.06, duration: 1 }, 0.4)
          .to('.case-cover', { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.8, ease: 'ch.inOut' }, 0.3)
          .to('.case-cover .gl-image', { scale: 1, duration: 2.2 }, 0.3)
      })
      // cover shrinks into the page as you scroll past
      gsap.to('.case-cover__inner', { scale: 0.86, borderRadius: 24, ease: 'none', scrollTrigger: { trigger: '.case-cover', start: 'top top', end: 'bottom top', scrub: true } })
      gsap.to('.case-hero__title', { yPercent: -30, opacity: 0.2, ease: 'none', scrollTrigger: { trigger: '.case-hero', start: 'top top', end: 'bottom top', scrub: true } })

      // statement colour flood
      gsap.fromTo('.case-statement', { '--flood': '0%' }, { '--flood': '100%', ease: 'none', scrollTrigger: { trigger: '.case-statement', start: 'top 80%', end: 'top 20%', scrub: true } })

      // next project: scroll to the end to pull it in
      let fired = false
      gsap.to('.case-next__progress circle', {
        strokeDashoffset: 0,
        ease: 'none',
        scrollTrigger: {
          trigger: '.case-next',
          start: 'top top',
          end: '+=90%',
          pin: true,
          scrub: true,
          onUpdate: (self) => {
            if (self.progress > 0.995 && !fired) {
              fired = true
              go(`/work/${next.slug}`, next.title)
            }
          },
        },
      })
      gsap.to('.case-next__img', { scale: 1, ease: 'none', scrollTrigger: { trigger: '.case-next', start: 'top bottom', end: 'top top', scrub: true } })
      return () => {
        off()
        split.revert()
      }
    },
    ref,
    [p.slug],
  )

  return (
    <main className="page page--case" ref={ref} style={{ ['--accent' as string]: p.color }} key={p.slug}>
      <section className="case-hero">
        <h1 className="case-hero__title">{p.title}</h1>
        <div className="case-hero__meta">
          <div>
            <span className="eyebrow">{p.status === 'concept' ? 'Company' : 'Client'}</span>
            <span>{p.client}</span>
          </div>
          <div>
            <span className="eyebrow">{p.services.length ? 'Services' : 'Industry'}</span>
            <span>{p.services.length ? p.services.join(', ') : p.industry}</span>
          </div>
          <div>
            <span className="eyebrow">{p.status === 'concept' ? 'Status' : 'Year'}</span>
            <span>{p.status === 'concept' ? 'Concept design' : p.year}</span>
          </div>
          <div className="case-hero__visit">
            {p.summary && <p className="case-hero__summary">{p.summary}</p>}
            {p.url && (
              <a className="pill-btn" href={p.url} target="_blank" rel="noopener noreferrer">
                <span className="pill-btn__fill" />
                <span className="pill-btn__text">Visit website</span>
                <span className="pill-btn__arrow">↗</span>
              </a>
            )}
          </div>
        </div>
      </section>

      <section className="case-cover" style={{ ['--pp-bg' as string]: p.color }}>
        <div className="case-cover__inner">
          {p.shots ? (
            <a
              className="case-frame"
              href={p.url || undefined}
              target="_blank"
              rel="noopener noreferrer"
              onPointerEnter={() => coverGl.current?.setHover(1)}
              onPointerLeave={() => coverGl.current?.setHover(0)}
              aria-label={`Visit the ${p.title} website (opens in a new tab)`}
            >
              <PreviewBar project={p} />
              <span className="case-frame__view case-frame__view--desktop">
                <GLImage ref={coverGl} src={p.shots.desktop.replace(/\.webp$/, '')} alt={`${p.title} website — homepage`} alignTop />
              </span>
              <span className="case-frame__view case-frame__view--mobile">
                <img src={asset(p.shots.mobile)} alt={`${p.title} website on mobile`} />
              </span>
            </a>
          ) : (
            <GLImage src={p.image} alt={`${p.title} key visual`} mode="reel" />
          )}
        </div>
      </section>

      {p.brief && (
        <section className="section case-body">
          <span className="eyebrow">(Challenge)</span>
          <Reveal as="p" className="case-body__text">
            {p.brief}
          </Reveal>
        </section>
      )}

      {p.shots && (
        <section className="case-gallery case-gallery--shots">
          <ParallaxMedia className="case-gallery__a" depth={0.02}>
            <img src={asset(p.shots.section)} alt={`${p.title} website — inner section`} />
          </ParallaxMedia>
          <ParallaxMedia className="case-gallery__b" depth={0.02} reveal="down">
            <img src={asset(p.shots.mobile)} alt={`${p.title} website on mobile`} />
          </ParallaxMedia>
          <ParallaxMedia className="case-gallery__c" depth={0.02} reveal="center">
            <img src={asset(p.shots.desktop)} alt={`${p.title} website — desktop homepage`} />
          </ParallaxMedia>
        </section>
      )}

      <section className="case-statement">
        <Reveal as="p" className="case-statement__text" type="words">
          Our approach: design the motion language first, then let everything else follow it.
        </Reveal>
      </section>

      <section className="case-next" data-cursor="view" data-cursor-label="Next" onClick={() => go(`/work/${next.slug}`, next.title)}>
        <div className="case-next__img">
          <img src={asset(`${next.image}.webp`)} alt="" />
        </div>
        <div className="case-next__content">
          <span className="eyebrow">Next project</span>
          <h2 className="case-next__title">{next.title}</h2>
          <svg className="case-next__progress" viewBox="0 0 100 100" aria-hidden>
            <circle cx="50" cy="50" r="46" pathLength={1} strokeDasharray="1" strokeDashoffset="1" />
          </svg>
          <span className="case-next__hint">Keep scrolling</span>
        </div>
      </section>
    </main>
  )
}
