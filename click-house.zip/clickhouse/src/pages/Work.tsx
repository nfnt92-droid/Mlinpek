import { useRef } from 'react'
import { projects } from '../data/projects'
import HoverList from '../components/HoverList'
import Reveal from '../components/Reveal'
import Footer from '../components/Footer'
import ProximityType from '../components/ProximityType'
import { useGsap } from '../lib/useGsap'
import { gsap } from '../lib/gsap'
import { onPageEnter } from '../lib/transition'

export default function Work() {
  const ref = useRef<HTMLElement>(null)
  useGsap(
    () => {
      gsap.set('.page-hero .px-char', { yPercent: 115 })
      gsap.set('.work-index .hover-list__row > :not(.hover-list__fill)', { yPercent: 80, opacity: 0 })
      return onPageEnter(() => {
        gsap.to('.page-hero .px-char', { yPercent: 0, stagger: 0.04, duration: 1.4, delay: 0.3 })
        gsap.to('.work-index .hover-list__row > :not(.hover-list__fill)', { yPercent: 0, opacity: 1, stagger: 0.025, duration: 1.2, delay: 0.6 })
      }) as unknown as () => void
    },
    ref,
  )
  return (
    <main className="page page--work" ref={ref}>
      <section className="page-hero">
        <span className="eyebrow">(Index) — {projects.length} projects</span>
        <h1 className="page-hero__title">
          <ProximityType text="Work" min={[72, 350]} max={[125, 850]} radius={0.3} />
          <sup className="page-hero__sup">({String(projects.length).padStart(2, '0')})</sup>
        </h1>
        <Reveal as="p" className="lede page-hero__lede" onEnter delay={0.3}>
          Brands, websites and interactive systems — each one built to respond, move and stay with you.
        </Reveal>
      </section>
      <section className="section work-index">
        <HoverList
          large
          items={projects.map((p) => ({ title: p.title, meta: p.status === 'concept' ? 'Concept' : p.year, tags: p.tags.join(' · '), image: p.image, to: `/work/${p.slug}` }))}
        />
      </section>
      <Footer />
    </main>
  )
}
