import { useRef, useState } from 'react'
import { gsap } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { onPageEnter } from '../lib/transition'
import ProximityType from '../components/ProximityType'
import Magnetic from '../components/Magnetic'
import RollText from '../components/RollText'
import Clock from '../components/Clock'

const BUDGETS = ['< €10k', '€10–25k', '€25–50k', '€50k +']
const INTERESTS = ['Brand identity', 'Website', 'Motion / WebGL', 'E-commerce', 'Something else']

export default function Contact() {
  const ref = useRef<HTMLElement>(null)
  const [interest, setInterest] = useState<string[]>([])
  const [budget, setBudget] = useState('')
  const [copied, setCopied] = useState(false)
  const [sent, setSent] = useState(false)

  useGsap(
    () => {
      gsap.set('.contact-hero .px-char', { yPercent: 115 })
      gsap.set('.contact-anim', { y: 40, opacity: 0 })
      return onPageEnter(() => {
        gsap.to('.contact-hero .px-char', { yPercent: 0, stagger: 0.035, duration: 1.4, delay: 0.3 })
        gsap.to('.contact-anim', { y: 0, opacity: 1, stagger: 0.06, duration: 1.2, delay: 0.6 })
      }) as unknown as () => void
    },
    ref,
  )

  const copy = () => {
    navigator.clipboard?.writeText('hello@clickhouse.studio')
    setCopied(true)
    setTimeout(() => setCopied(false), 1800)
  }
  const toggle = (v: string) => setInterest((s) => (s.includes(v) ? s.filter((x) => x !== v) : [...s, v]))

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    fd.set('interest', interest.join(', '))
    fd.set('budget', budget)
    try {
      await fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(fd as unknown as Record<string, string>).toString() })
    } catch {
      /* offline preview */
    }
    setSent(true)
  }

  return (
    <main className="page page--contact" ref={ref}>
      <section className="contact-hero page-hero">
        <span className="eyebrow">(Contact)</span>
        <h1 className="contact-hero__title">
          <ProximityType text="Say hello" radius={0.3} />
        </h1>
        <div className="contact-hero__mail contact-anim">
          <Magnetic strength={0.2} innerStrength={0.1}>
            <button className="big-mail" onClick={copy} data-cursor="stick">
              hello@clickhouse.studio
            </button>
          </Magnetic>
          <span className={`copied ${copied ? 'is-on' : ''}`}>Copied to clipboard ✓</span>
        </div>
      </section>

      <section className="section contact-grid">
        <aside className="contact-aside contact-anim">
          <div>
            <span className="eyebrow">Local time</span>
            <Clock />
          </div>
          <div>
            <span className="eyebrow">Follow</span>
            {['Instagram', 'Behance', 'LinkedIn'].map((s) => (
              <a key={s} href="#" data-cursor="link">
                <RollText text={s} />
              </a>
            ))}
          </div>
        </aside>

        {sent ? (
          <div className="contact-sent contact-anim">
            <h2>
              Thank you — <em className="serif">we’ll be in touch</em> within two working days.
            </h2>
          </div>
        ) : (
          <form className="contact-form" name="project" method="POST" data-netlify="true" netlify-honeypot="bot-field" onSubmit={submit}>
            <input type="hidden" name="form-name" value="project" />
            <p hidden>
              <label>
                Don’t fill this out: <input name="bot-field" />
              </label>
            </p>
            <fieldset className="contact-anim">
              <legend>I’m interested in…</legend>
              <div className="chips">
                {INTERESTS.map((v) => (
                  <Magnetic key={v} strength={0.25}>
                    <button type="button" className={`chip ${interest.includes(v) ? 'is-on' : ''}`} onClick={() => toggle(v)} data-cursor="stick">
                      {v}
                    </button>
                  </Magnetic>
                ))}
              </div>
            </fieldset>
            <div className="field contact-anim">
              <input id="name" name="name" required placeholder=" " autoComplete="name" />
              <label htmlFor="name">Your name</label>
              <span className="field__line" />
            </div>
            <div className="field contact-anim">
              <input id="email" name="email" type="email" required placeholder=" " autoComplete="email" />
              <label htmlFor="email">Email</label>
              <span className="field__line" />
            </div>
            <div className="field contact-anim">
              <textarea id="msg" name="message" rows={3} placeholder=" " />
              <label htmlFor="msg">Tell us about the project</label>
              <span className="field__line" />
            </div>
            <fieldset className="contact-anim">
              <legend>Budget</legend>
              <div className="chips">
                {BUDGETS.map((v) => (
                  <Magnetic key={v} strength={0.25}>
                    <button type="button" className={`chip ${budget === v ? 'is-on' : ''}`} onClick={() => setBudget(v)} data-cursor="stick">
                      {v}
                    </button>
                  </Magnetic>
                ))}
              </div>
            </fieldset>
            <div className="contact-anim">
              <Magnetic strength={0.5} innerStrength={0.25} padding={50}>
                <button type="submit" className="round-btn round-btn--signal" data-cursor="hide">
                  <span className="round-btn__fill" />
                  <span className="round-btn__text">
                    <RollText text="Send it" />
                  </span>
                </button>
              </Magnetic>
            </div>
          </form>
        )}
      </section>
    </main>
  )
}
