import { useRef } from 'react'
import { gsap, ScrollTrigger } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { onPageEnter } from '../lib/transition'
import { pointer, damp } from '../lib/pointer'
import ProximityType from '../components/ProximityType'
import GLImage from '../components/GLImage'
import { isTouch, prefersReduced } from '../lib/env'

/**
 * Pinned hero. A small media window sits inside the headline; scrolling
 * pulls it open to a full-bleed live reel while the lines split away.
 */
export default function Hero() {
  const ref = useRef<HTMLElement>(null)

  useGsap(
    () => {
      const hero = ref.current!
      const media = hero.querySelector<HTMLElement>('.hero__media')!
      const slot = hero.querySelector<HTMLElement>('.hero__slot')!
      const photo = media.querySelector<HTMLElement>('.gl-image')
      const box = { t: 0, l: 0, w: 0, h: 0 }
      const st = { p: 0, intro: 0 }

      const measure = () => {
        let t = 0
        let l = 0
        let n: HTMLElement | null = slot
        while (n && n !== hero) {
          t += n.offsetTop
          l += n.offsetLeft
          n = n.offsetParent as HTMLElement | null
        }
        box.t = t
        box.l = l
        box.w = slot.offsetWidth
        box.h = slot.offsetHeight
        apply()
      }
      const lerp = (a: number, b: number, k: number) => a + (b - a) * k
      const apply = () => {
        const W = hero.offsetWidth
        const H = hero.offsetHeight
        const k = st.p
        const w = box.w * st.intro
        const l = box.l + (box.w - w) / 2
        const top = lerp(box.t, 0, k)
        const left = lerp(l, 0, k)
        const right = lerp(W - l - w, 0, k)
        const bottom = lerp(H - box.t - box.h, 0, k)
        const rad = lerp(box.h / 2, 0, k)
        media.style.clipPath = `inset(${top}px ${right}px ${bottom}px ${left}px round ${rad}px)`
        // Frame the eye inside the small window: centre the photo on the slot and
        // scale it so the eye fills it, then ease back to full-bleed as it opens.
        const IMG_W = 2320
        const IMG_H = 1305
        const EYE_W = 460 // eye width in source pixels (eye is at the image centre)
        const cover = Math.max(W / IMG_W, H / IMG_H)
        const slotCx = box.l + box.w / 2
        const slotCy = box.t + box.h / 2
        const minS = Math.max(box.w / (IMG_W * cover), box.h / (IMG_H * cover))
        const s0 = Math.min(1, Math.max(minS, (box.w * 0.92) / (EYE_W * cover)))
        const sc = lerp(s0, 1, k)
        const dx = lerp(slotCx - W / 2, 0, k)
        const dy = lerp(slotCy - H / 2, 0, k)
        if (photo) photo.style.transform = `translate3d(${dx}px, ${dy}px, 0) scale(${sc})`
      }

      gsap.set('.hero .px-char', { yPercent: 115 })
      gsap.set('.hero__meta > *', { opacity: 0, y: 16 })
      measure()
      ScrollTrigger.addEventListener('refreshInit', measure)
      const ro = new ResizeObserver(measure)
      ro.observe(hero)

      const off = onPageEnter(() => {
        const tl = gsap.timeline({ delay: 0.25 })
        tl.to('.hero .px-char', { yPercent: 0, duration: 1.4, stagger: 0.028, ease: 'ch.out' })
          .to(st, { intro: 1, duration: 1.4, ease: 'ch.inOut', onUpdate: apply }, 0.5)
          .to('.hero__meta > *', { opacity: 1, y: 0, duration: 1, stagger: 0.08 }, 0.9)
      })

      if (!prefersReduced) {
        const tl = gsap.timeline({
          scrollTrigger: { trigger: hero, start: 'top top', end: '+=160%', pin: true, scrub: 1, anticipatePin: 1 },
        })
        tl.to(st, { p: 1, ease: 'ch.inOut', duration: 1, onUpdate: apply }, 0)
          .to('.hero__line--1', { yPercent: -240, xPercent: -8, opacity: 0, ease: 'ch.in', duration: 0.8 }, 0)
          .to('.hero__line--3', { yPercent: 240, xPercent: 8, opacity: 0, ease: 'ch.in', duration: 0.8 }, 0)
          .to('.hero__line--2 .px-type', { xPercent: 40, ease: 'ch.in', duration: 0.8 }, 0)
          .to('.hero__meta', { opacity: 0, duration: 0.3 }, 0)
          .fromTo('.hero__reel-ui', { opacity: 0 }, { opacity: 1, duration: 0.3 }, 0.75)
          .fromTo('.hero__reel-title span', { yPercent: 110 }, { yPercent: 0, stagger: 0.05, duration: 0.4, ease: 'ch.out' }, 0.75)
          .to({}, { duration: 0.25 })
      }

      // whole headline drifts against the cursor → depth
      const title = hero.querySelector<HTMLElement>('.hero__title')!
      const d = { x: 0, y: 0 }
      const tick = (_t: number, dt: number) => {
        d.x += (pointer.nx * -14 - d.x) * damp(0.05, dt)
        d.y += (pointer.ny * -10 - d.y) * damp(0.05, dt)
        title.style.transform = `translate3d(${d.x}px, ${d.y}px, 0)`
      }
      gsap.ticker.add(tick)

      return () => {
        off()
        ro.disconnect()
        gsap.ticker.remove(tick)
        ScrollTrigger.removeEventListener('refreshInit', measure)
      }
    },
    ref,
  )

  return (
    <section className="hero" ref={ref}>
      <h1 className="hero__title" aria-label="Digital experiences you can feel.">
        <span className="hero__line hero__line--1">
          <ProximityType text="Digital" />
        </span>
        <span className="hero__line hero__line--2">
          <span className="hero__slot" aria-hidden />
          <ProximityType text="experiences" />
        </span>
        <span className="hero__line hero__line--3">
          <ProximityType text="you can" />
          <em className="serif hero__feel">
            <span className="px-char-mask">
              <span className="px-char">feel.</span>
            </span>
          </em>
        </span>
      </h1>

      <div className="hero__media" data-cursor="view" data-cursor-label="Play reel">
        <GLImage src="img/hero" alt="Black-and-white close-up of an eye caught in a slice of light" mode="reel" />
        <div className="hero__reel-ui">
          <p className="hero__reel-title mask-line">
            <span>Showreel</span> <span className="serif">’26</span>
          </p>
          <p className="hero__reel-note">{isTouch ? 'Touch & drag — it’s alive.' : 'Move your cursor — it’s alive.'}</p>
        </div>
      </div>

      <div className="hero__meta">
        <span className="eyebrow">(Creative digital studio)</span>
        <span className="hero__scroll">
          <span className="hero__scroll-line" />
          Scroll to explore
        </span>
        <span className="eyebrow hero__meta-right">Brand · Web · Motion</span>
      </div>
    </section>
  )
}
