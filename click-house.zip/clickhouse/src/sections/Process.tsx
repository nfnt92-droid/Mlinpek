import { useRef } from 'react'
import { gsap } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { asset } from '../lib/env'

const STEPS = [
  { n: '01', t: 'Listen', d: 'We start with your people, your market and the feeling you want to leave behind.', img: 'img/process/listen' },
  { n: '02', t: 'Shape', d: 'Strategy and story become a system: type, colour, rhythm — and a motion language.', img: 'img/process/shape' },
  { n: '03', t: 'Move', d: 'We prototype interaction early, in the browser, so every transition is felt before it is final.', img: 'img/process/move' },
  { n: '04', t: 'Launch', d: 'Engineered for speed, accessibility and search. Then we keep tuning after go-live.', img: 'img/process/launch' },
]

/** Horizontal pinned track on desktop; vertical stack on touch/narrow screens. */
export default function Process() {
  const ref = useRef<HTMLElement>(null)
  useGsap(
    () => {
      const mm = gsap.matchMedia()
      mm.add('(min-width: 900px)', () => {
        const track = ref.current!.querySelector<HTMLElement>('.process__track')!
        const dist = () => track.scrollWidth - window.innerWidth
        const tween = gsap.to(track, {
          x: () => -dist(),
          ease: 'none',
          scrollTrigger: { trigger: ref.current, start: 'top top', end: () => `+=${dist()}`, pin: true, scrub: 1, invalidateOnRefresh: true },
        })
        gsap.to('.process__progress-bar', { scaleX: 1, ease: 'none', scrollTrigger: { trigger: ref.current, start: 'top top', end: () => `+=${dist()}`, scrub: true } })
        gsap.utils.toArray<HTMLElement>('.process__panel').forEach((panel) => {
          gsap.fromTo(panel.querySelector('img'), { xPercent: -4, scale: 1.1 }, { xPercent: 4, scale: 1.1, ease: 'none', scrollTrigger: { trigger: panel, containerAnimation: tween, start: 'left right', end: 'right left', scrub: true } })
          gsap.from(panel.querySelector('.process__num'), { yPercent: 100, ease: 'ch.out', duration: 1, scrollTrigger: { trigger: panel, containerAnimation: tween, start: 'left 70%' } })
          gsap.fromTo(panel.querySelector('.process__img'), { clipPath: 'inset(0% 100% 0% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', ease: 'ch.out', duration: 1.4, scrollTrigger: { trigger: panel, containerAnimation: tween, start: 'left 80%' } })
        })
      })
      mm.add('(max-width: 899px)', () => {
        gsap.utils.toArray<HTMLElement>('.process__panel').forEach((panel) => {
          gsap.fromTo(panel.querySelector('.process__img'), { clipPath: 'inset(100% 0% 0% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.4, scrollTrigger: { trigger: panel, start: 'top 80%' } })
        })
      })
      return () => mm.revert()
    },
    ref,
  )
  return (
    <section className="process" ref={ref}>
      <div className="process__head">
        <span className="eyebrow">(04) — Process</span>
        <div className="process__progress">
          <span className="process__progress-bar" />
        </div>
      </div>
      <div className="process__track">
        <div className="process__intro">
          <h2 className="process__big">
            How we
            <br />
            <em className="serif">get there</em>
          </h2>
        </div>
        {STEPS.map((s) => (
          <article className="process__panel" key={s.n}>
            <div className="process__num-mask">
              <span className="process__num">{s.n}</span>
            </div>
            <div className="process__img">
              <img src={asset(`${s.img}.webp`)} alt="" loading="lazy" />
            </div>
            <h3 className="process__title">{s.t}</h3>
            <p className="process__desc">{s.d}</p>
          </article>
        ))}
      </div>
    </section>
  )
}
