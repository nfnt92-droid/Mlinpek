import { useRef } from 'react'
import { gsap, SplitText } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { asset } from '../lib/env'
import Magnetic from '../components/Magnetic'
import { TLink } from '../components/TransitionProvider'

/** Paragraph that "inks in" word by word as you scroll, with inline image pills. */
export default function Manifesto() {
  const ref = useRef<HTMLElement>(null)
  useGsap(
    () => {
      const p = ref.current!.querySelector<HTMLElement>('.manifesto__text')!
      const split = SplitText.create(p, { type: 'words', wordsClass: 'mf-word' })
      gsap.fromTo(
        split.words,
        { opacity: 0.12 },
        { opacity: 1, stagger: 0.1, ease: 'none', scrollTrigger: { trigger: p, start: 'top 75%', end: 'bottom 45%', scrub: true } },
      )
      ref.current!.querySelectorAll<HTMLElement>('.manifesto__pill').forEach((pill) => {
        gsap.fromTo(pill, { width: 0 }, { width: pill.dataset.w, ease: 'ch.inOut', scrollTrigger: { trigger: pill, start: 'top 80%', end: 'top 45%', scrub: 1 } })
        gsap.fromTo(pill.querySelector('img'), { scale: 1.6 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: pill, start: 'top 85%', end: 'top 30%', scrub: true } })
      })
      gsap.from('.manifesto__aside > *', { y: 30, opacity: 0, stagger: 0.1, duration: 1.2, scrollTrigger: { trigger: ref.current, start: 'top 70%' } })
      return () => split.revert()
    },
    ref,
  )
  return (
    <section className="manifesto section" ref={ref}>
      <div className="manifesto__aside">
        <span className="eyebrow">(01) — Approach</span>
        <span className="manifesto__count">©CH</span>
      </div>
      <p className="manifesto__text">
        We are Click House — a creative digital studio designing brands and websites around
        <span className="manifesto__pill" data-w="2.1em">
          <img src={asset('img/verde-sm.webp')} alt="" />
        </span>
        movement. Every scroll, hover and click is a chance to make someone <em className="serif">feel</em> something. So we treat interaction as
        <span className="manifesto__pill" data-w="2.1em">
          <img src={asset('img/pulse-sm.webp')} alt="" />
        </span>
        material — shaped, timed and tuned until the screen feels <em className="serif">alive</em> under your hand.
      </p>
      <div className="manifesto__cta">
        <Magnetic strength={0.4} innerStrength={0.2}>
          <TLink to="/studio" label="Studio" className="pill-btn" data-cursor="stick">
            <span className="pill-btn__fill" />
            <span className="pill-btn__text">About the studio</span>
            <span className="pill-btn__arrow">→</span>
          </TLink>
        </Magnetic>
      </div>
    </section>
  )
}
