import { useCallback, useRef, useState } from 'react'
import { gsap } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { featuredProjects, projects, type Project } from '../data/projects'
import ProjectPreview, { PreviewBar, type PreviewHandle } from '../components/ProjectPreview'
import { TLink } from '../components/TransitionProvider'
import Reveal from '../components/Reveal'
import Magnetic from '../components/Magnetic'
import RollText from '../components/RollText'
import { isTouch } from '../lib/env'

function WorkCard({ p, i }: { p: Project; i: number }) {
  const preview = useRef<PreviewHandle>(null)
  const card = useRef<HTMLElement>(null)
  const tilt = useRef<{ rx: gsap.QuickToFunc; ry: gsap.QuickToFunc } | null>(null)
  const [live, setLive] = useState(false)
  const [interactive, setInteractive] = useState(false)
  const onLiveReady = useCallback((v: boolean) => setLive(v), [])
  const hasUrl = !!p.url

  const move = (e: React.PointerEvent) => {
    if (isTouch || interactive) return
    const el = card.current!.querySelector<HTMLElement>('.work-card__media')!
    if (!tilt.current) tilt.current = { rx: gsap.quickTo(el, 'rotationX', { duration: 0.8, ease: 'power3.out' }), ry: gsap.quickTo(el, 'rotationY', { duration: 0.8, ease: 'power3.out' }) }
    const r = el.getBoundingClientRect()
    tilt.current.rx(-((e.clientY - r.top) / r.height - 0.5) * 6)
    tilt.current.ry(((e.clientX - r.left) / r.width - 0.5) * 8)
  }
  const enter = () => preview.current?.setHover(1)
  const leave = () => {
    preview.current?.setHover(0)
    tilt.current?.rx(0)
    tilt.current?.ry(0)
  }
  const toggleLive = () => {
    setInteractive((v) => !v)
    tilt.current?.rx(0)
    tilt.current?.ry(0)
  }

  const linkProps = { href: p.url, target: '_blank', rel: 'noopener noreferrer' }
  const meta = [p.industry, ...p.services].filter(Boolean)

  return (
    <article
      className={`work-card work-card--${i} ${interactive ? 'is-live' : ''}`}
      ref={card}
      onPointerMove={move}
      onPointerEnter={enter}
      onPointerLeave={leave}
      data-speed={[0.9, 1.15, 1.05, 0.85][i]}
    >
      <div className="work-card__media-wrap">
        <div className="work-card__media">
          <div className="work-card__clip" style={{ background: p.color }}>
            <PreviewBar project={p} />
            <div className="work-card__viewport">
              <div className="work-card__inner">
                <ProjectPreview ref={preview} project={p} variant={i} interactive={interactive} onLiveReady={onLiveReady} />
              </div>
            </div>
          </div>
          {!interactive &&
            (hasUrl ? (
              <a className="work-card__hit" {...linkProps} aria-label={`Visit the ${p.title} website (opens in a new tab)`} data-cursor="view" data-cursor-label="Visit site ↗" />
            ) : (
              <span className="work-card__hit" data-cursor="view" data-cursor-label="Coming soon" aria-hidden />
            ))}
          {live && !isTouch && (
            <button className="work-card__live" onClick={toggleLive} data-cursor="stick">
              {interactive ? 'Close preview ×' : 'Explore live ⟷'}
            </button>
          )}
        </div>
      </div>
      <div className="work-card__info">
        <span className="work-card__index">({String(i + 1).padStart(2, '0')})</span>
        <h3 className="work-card__title">
          <span className="work-card__title-mask">
            <span className="work-card__title-text">{p.title}</span>
          </span>
        </h3>
        {meta.length > 0 && <span className="work-card__tags">{meta.join(' · ')}</span>}
        <span className="work-card__year">{p.status === 'concept' ? <span className="work-card__badge">Concept</span> : p.year}</span>
        <span className="work-card__visit">
          {hasUrl ? (
            <a {...linkProps} data-cursor="link">
              <RollText text="Visit website" /> <span className="work-card__arrow">↗</span>
            </a>
          ) : (
            <span className="work-card__soon">Link coming soon</span>
          )}
        </span>
      </div>
    </article>
  )
}

export default function SelectedWork() {
  const ref = useRef<HTMLElement>(null)
  useGsap(
    () => {
      const mm = gsap.matchMedia()
      gsap.utils.toArray<HTMLElement>('.work-card').forEach((card) => {
        const clip = card.querySelector('.work-card__clip')
        const inner = card.querySelector('.work-card__inner')
        const info = card.querySelector('.work-card__info')
        gsap.fromTo(clip, { clipPath: 'inset(100% 0% 0% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.6, ease: 'ch.out', scrollTrigger: { trigger: card, start: 'top 85%' } })
        gsap.fromTo(inner, { scale: 1.4 }, { scale: 1, duration: 2, ease: 'ch.out', scrollTrigger: { trigger: card, start: 'top 85%' } })
        gsap.fromTo(inner, { yPercent: -4 }, { yPercent: 4, ease: 'none', scrollTrigger: { trigger: card, start: 'top bottom', end: 'bottom top', scrub: true } })
        gsap.from(card.querySelector('.work-card__title-text'), { yPercent: 110, duration: 1.2, scrollTrigger: { trigger: info, start: 'top 95%' } })
        gsap.from(card.querySelectorAll('.work-card__index, .work-card__tags, .work-card__year, .work-card__visit'), { opacity: 0, y: 12, stagger: 0.06, duration: 1, scrollTrigger: { trigger: info, start: 'top 95%' } })
      })
      mm.add('(min-width: 900px)', () => {
        gsap.utils.toArray<HTMLElement>('.work-card').forEach((card) => {
          const s = parseFloat(card.dataset.speed || '1')
          gsap.fromTo(card, { y: (1 - s) * -300 }, { y: (1 - s) * 300, ease: 'none', scrollTrigger: { trigger: card, start: 'top bottom', end: 'bottom top', scrub: true } })
        })
      })
      return () => mm.revert()
    },
    ref,
  )
  return (
    <section className="work section" ref={ref}>
      <header className="section-head">
        <span className="eyebrow">(02) — Selected work</span>
        <Reveal as="h2" className="section-title" type="chars">
          Work that <em className="serif">moves</em>
        </Reveal>
      </header>
      <div className="work__grid">
        {featuredProjects.slice(0, 4).map((p, i) => (
          <WorkCard p={p} i={i} key={p.slug} />
        ))}
      </div>
      <div className="work__more">
        <Magnetic strength={0.5} innerStrength={0.25} padding={50}>
          <TLink to="/work" label="Work" className="round-btn" data-cursor="hide">
            <span className="round-btn__fill" />
            <span className="round-btn__text round-btn__text--stack">
              <RollText text="Explore" />
              <span>
                <RollText text="all work" />
                <sup>({projects.length})</sup>
              </span>
            </span>
          </TLink>
        </Magnetic>
      </div>
    </section>
  )
}
