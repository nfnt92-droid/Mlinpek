import { useRef } from 'react'
import { useGsap } from '../lib/useGsap'
import { gsap } from '../lib/gsap'
import HoverList from '../components/HoverList'
import Marquee from '../components/Marquee'
import Reveal from '../components/Reveal'

const SERVICES = [
  { title: 'Brand identity', meta: 'Strategy, naming, visual systems', image: 'img/halcyon' },
  { title: 'Websites', meta: 'Design & creative development', image: 'img/northbound' },
  { title: 'Photography', meta: 'Editorial, product & brand imagery', image: 'img/pulse' },
  { title: 'Videography', meta: 'Brand films, reels & motion content', image: 'img/saltworks' },
  { title: 'Art direction', meta: 'Campaigns, imagery, content', image: 'img/atelier' },
]

export default function Services() {
  const ref = useRef<HTMLElement>(null)
  useGsap(
    () => {
      gsap.from('.services .hover-list__row > :not(.hover-list__fill)', {
        yPercent: 80,
        opacity: 0,
        stagger: 0.03,
        duration: 1.2,
        scrollTrigger: { trigger: '.services .hover-list', start: 'top 85%' },
      })
    },
    ref,
  )
  return (
    <section className="services" ref={ref}>
      <Marquee items={['Strategy', 'Identity', 'Interaction', 'Motion', 'Websites', 'Craft']} speed={0.7} className="marquee--big" />
      <Marquee items={['Designed around movement', 'Built to be felt', 'Tuned by hand']} speed={0.5} reverse className="marquee--small" />
      <div className="section">
        <header className="section-head section-head--split">
          <span className="eyebrow">(03) — Capabilities</span>
          <Reveal as="p" className="lede">
            Five disciplines, one obsession: how it feels when you touch it. We work from first sketch to final frame, in-house.
          </Reveal>
        </header>
        <HoverList items={SERVICES} follow={false} />
      </div>
    </section>
  )
}
