import { useRef, type ElementType, type ReactNode } from 'react'
import { gsap, SplitText } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { onPageEnter } from '../lib/transition'

type Props = {
  as?: ElementType
  children: ReactNode
  className?: string
  /** 'lines' rises line by line from a mask; 'chars' staggers letters with a slight rotation */
  type?: 'lines' | 'chars' | 'words'
  /** play on page enter instead of on scroll */
  onEnter?: boolean
  delay?: number
}

/** Masked SplitText reveal; re-splits responsively. */
export default function Reveal({ as: Tag = 'div', children, className = '', type = 'lines', onEnter, delay = 0 }: Props) {
  const ref = useRef<HTMLElement>(null)
  useGsap(
    () => {
      const el = ref.current!
      let off: (() => void) | undefined
      const split = SplitText.create(el, {
        type: type === 'lines' ? 'lines' : type === 'words' ? 'words,lines' : 'chars,words,lines',
        mask: type === 'chars' ? 'words' : 'lines',
        linesClass: 'split-line',
        autoSplit: true,
        onSplit(self) {
          const targets = type === 'lines' ? self.lines : type === 'words' ? self.words : self.chars
          const vars: gsap.TweenVars = {
            yPercent: 110,
            rotate: type === 'chars' ? 6 : 2,
            transformOrigin: '0% 100%',
            duration: type === 'chars' ? 1.2 : 1.3,
            stagger: type === 'chars' ? 0.025 : type === 'words' ? 0.03 : 0.09,
            delay,
          }
          if (onEnter) {
            gsap.set(targets, { yPercent: 110, rotate: vars.rotate })
            off?.()
            off = onPageEnter(() => gsap.to(targets, { yPercent: 0, rotate: 0, duration: vars.duration, stagger: vars.stagger, delay: (delay as number) + 0.35 }))
            return
          }
          return gsap.from(targets, { ...vars, scrollTrigger: { trigger: el, start: 'top 88%' } })
        },
      })
      el.style.visibility = 'visible'
      return () => {
        off?.()
        split.revert()
      }
    },
    ref,
  )
  return (
    <Tag ref={ref} className={`reveal ${className}`}>
      {children}
    </Tag>
  )
}
