import { useEffect, useRef, type ReactNode, type ElementType, type HTMLAttributes } from 'react'
import { registerMagnet } from '../lib/magnetic'

type Props = HTMLAttributes<HTMLElement> & {
  children: ReactNode
  strength?: number
  innerStrength?: number
  padding?: number
  as?: ElementType
}

/** Wraps content in a magnetic field. The inner layer drifts further → parallax depth. */
export default function Magnetic({ children, strength, innerStrength, padding, as: Tag = 'span', className = '', ...rest }: Props) {
  const ref = useRef<HTMLElement>(null)
  useEffect(() => {
    if (!ref.current) return
    return registerMagnet(ref.current, { strength, innerStrength, padding })
  }, [strength, innerStrength, padding])
  return (
    <Tag ref={ref} className={`magnetic ${className}`} {...rest}>
      <span className="magnetic__inner" data-magnet-inner>
        {children}
      </span>
    </Tag>
  )
}
