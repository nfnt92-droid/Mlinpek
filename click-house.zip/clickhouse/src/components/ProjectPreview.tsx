import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react'
import type { Project } from '../data/projects'
import { domainOf } from '../data/projects'
import GLImage, { type GLImageHandle } from './GLImage'

export type PreviewHandle = { setHover: (v: number) => void }

type Props = {
  project: Project
  variant: number
  interactive: boolean
  onLiveReady?: (ready: boolean) => void
}

/**
 * Browser-framed website preview.
 *  - preview img → static screenshot (top-anchored) with the WebGL hover lens
 *  - no preview   → typographic cover in the project's palette
 *  - "Explore live" (url + embed) → the real site, scaled into the frame and
 *    scrollable; only requested on click, so the page stays light.
 */
const ProjectPreview = forwardRef<PreviewHandle, Props>(function ProjectPreview({ project: p, variant, interactive, onLiveReady }, ref) {
  const host = useRef<HTMLDivElement>(null)
  const gl = useRef<GLImageHandle>(null)
  const [loaded, setLoaded] = useState(false)
  const [failed, setFailed] = useState(false)
  const [box, setBox] = useState({ w: 0, h: 0 })
  const canEmbed = !!p.url && p.embed
  const showFrame = canEmbed && interactive

  useImperativeHandle(ref, () => ({ setHover: (v) => gl.current?.setHover(v) }))

  useEffect(() => onLiveReady?.(canEmbed), [canEmbed, onLiveReady])

  // the live site is only requested when the visitor asks for it
  useEffect(() => {
    if (!showFrame) {
      setLoaded(false)
      setFailed(false)
      return
    }
    const t = setTimeout(() => setFailed(true), 9000)
    return () => clearTimeout(t)
  }, [showFrame])

  useEffect(() => {
    if (!host.current) return
    const ro = new ResizeObserver(([e]) => setBox({ w: e.contentRect.width, h: e.contentRect.height }))
    ro.observe(host.current)
    return () => ro.disconnect()
  }, [])

  // render narrow cards as a phone viewport, wide cards as desktop
  const virtualW = box.w < 520 ? 430 : 1280
  const scale = box.w ? box.w / virtualW : 1
  return (
    <div className="pp" style={{ ['--pp-bg' as string]: p.color, ['--pp-ink' as string]: p.ink }}>
      <div className="pp__view" ref={host}>
        {p.preview ? (
          <GLImage ref={gl} src={p.preview.replace(/\.(webp|jpe?g|png)$/i, '')} alt={`${p.title} website preview`} alignTop />
        ) : (
          <Cover p={p} variant={variant} />
        )}
        {showFrame && box.w > 0 && (
          <iframe
            className={`pp__frame ${loaded ? 'is-loaded' : ''}`}
            src={p.url}
            title={`${p.title} — live website preview`}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            sandbox="allow-scripts allow-same-origin allow-popups"
            tabIndex={interactive ? 0 : -1}
            onLoad={() => {
              setLoaded(true)
              setFailed(false)
            }}
            style={{
              width: virtualW,
              height: box.h / scale,
              transform: `scale(${scale})`,
              pointerEvents: 'auto',
            }}
          />
        )}
        {showFrame && !loaded && (
          <div className="pp__loading">
            {failed ? (
              <a href={p.url} target="_blank" rel="noopener noreferrer">
                Live preview unavailable here — visit website ↗
              </a>
            ) : (
              <span>Loading live site…</span>
            )}
          </div>
        )}
      </div>
    </div>
  )
})

/** Browser chrome — rendered outside the parallax layer so it never crops. */
export function PreviewBar({ project: p }: { project: Project }) {
  const domain = domainOf(p.url)
  return (
    <div className="pp__bar" aria-hidden style={{ ['--pp-bg' as string]: p.color, ['--pp-ink' as string]: p.ink }}>
      <span className="pp__dots">
        <i />
        <i />
        <i />
      </span>
      <span className="pp__addr">{domain || 'Link coming soon'}</span>
      <span className="pp__status">{p.status === 'concept' ? 'Concept' : 'Live'}</span>
    </div>
  )
}

/** Designed stand-in when there is no URL or screenshot yet. */
function Cover({ p, variant }: { p: Project; variant: number }) {
  const initial = p.title.replace(/[^A-Za-zČĆŽŠĐ]/g, '').charAt(0)
  return (
    <div className={`pp-cover pp-cover--${variant % 4}`} aria-hidden>
      <span className="pp-cover__pattern" />
      <span className="pp-cover__mono">{initial}</span>
      <span className="pp-cover__top">
        <span>{p.industry || ' '}</span>
        <span>{p.status === 'concept' ? 'Concept design' : 'Client work'}</span>
      </span>
      <span className="pp-cover__name">{p.title}</span>
    </div>
  )
}

export default ProjectPreview
