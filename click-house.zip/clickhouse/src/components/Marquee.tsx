import { useEffect, useRef } from 'react'
import { gsap } from '../lib/gsap'
import { scrollState } from '../lib/scroll'
import { damp } from '../lib/pointer'

type Props = { items: string[]; speed?: number; reverse?: boolean; className?: string }

/** Endless horizontal row that speeds up and reverses with scroll velocity. */
export default function Marquee({ items, speed = 0.6, reverse = false, className = '' }: Props) {
  const track = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = track.current!
    let x = 0
    let boost = 0
    let visible = true
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting))
    io.observe(el)
    const tick = (_t: number, dt: number) => {
      if (!visible) return
      const half = el.scrollWidth / 2
      const v = scrollState.velocity
      boost += (v * 0.35 - boost) * damp(0.1, dt)
      const dir = (reverse ? -1 : 1) * scrollState.direction
      x -= (speed * dir + boost * (reverse ? -1 : 1)) * (dt / 16.67)
      if (x <= -half) x += half
      if (x > 0) x -= half
      el.style.transform = `translate3d(${x}px,0,0)`
    }
    gsap.ticker.add(tick)
    return () => {
      gsap.ticker.remove(tick)
      io.disconnect()
    }
  }, [speed, reverse])

  const row = (k: string) => (
    <div className="marquee__row" key={k} aria-hidden={k === 'b'}>
      {items.map((t, i) => (
        <span className="marquee__item" key={i}>
          {i % 2 ? <em className="serif">{t}</em> : t}
          <span className="marquee__star">✺</span>
        </span>
      ))}
    </div>
  )
  return (
    <div className={`marquee ${className}`}>
      <div className="marquee__track" ref={track}>
        {row('a')}
        {row('b')}
      </div>
    </div>
  )
}
