import { useLayoutEffect, useRef, useState } from 'react'
import { gsap, ScrollTrigger } from '../lib/gsap'
import { emitPageEnter } from '../lib/transition'
import { startScroll, stopScroll } from '../lib/scroll'
import { asset, prefersReduced } from '../lib/env'

const preload = (src: string) =>
  new Promise<void>((res) => {
    const i = new Image()
    i.onload = i.onerror = () => res()
    i.src = src
  })

/** Counter → wordmark → columns lift. Waits for fonts + key imagery. */
export default function Preloader() {
  const root = useRef<HTMLDivElement>(null)
  const num = useRef<HTMLSpanElement>(null)
  const bar = useRef<HTMLDivElement>(null)
  const [gone, setGone] = useState(false)

  useLayoutEffect(() => {
    stopScroll()
    const state = { p: 0, target: 0 }
    const assets = ['img/studio.webp', 'img/halcyon-sm.webp', 'img/northbound-sm.webp', 'img/verde-sm.webp', 'img/atelier-sm.webp']
    let done = 0
    const total = assets.length + 1
    const bump = () => {
      done++
      state.target = done / total
    }
    const loads = [document.fonts.ready.then(bump), ...assets.map((a) => preload(asset(a)).then(bump))]
    const minTime = new Promise((r) => setTimeout(r, prefersReduced ? 0 : 1500))

    const ctx = gsap.context(() => {
      gsap.from('.preloader__word span', { yPercent: 110, duration: 1.1, stagger: 0.04, ease: 'ch.out', delay: 0.1 })
      const tick = () => {
        state.p += (state.target - state.p) * 0.08
        const v = Math.round(state.p * 100)
        if (num.current) num.current.textContent = String(v).padStart(3, '0')
        if (bar.current) bar.current.style.transform = `scaleX(${state.p})`
      }
      gsap.ticker.add(tick)
      Promise.all([...loads, minTime]).then(() => {
        state.target = 1
        gsap
          .timeline({
            delay: 0.35,
            onComplete: () => {
              gsap.ticker.remove(tick)
              setGone(true)
            },
          })
          .to('.preloader__count span, .preloader__word span, .preloader__meta span', { yPercent: -110, duration: 0.8, stagger: 0.02, ease: 'ch.in' })
          .to('.preloader__bar', { scaleX: 0, transformOrigin: '100% 50%', duration: 0.6, ease: 'ch.inOut' }, 0)
          .add(() => {
            ScrollTrigger.refresh()
            emitPageEnter()
            startScroll()
          }, 0.75)
          .to('.preloader__col', { scaleY: 0, transformOrigin: '50% 0%', duration: 1.0, stagger: { each: 0.07, from: 'start' }, ease: 'ch.inOut' }, 0.55)
      })
    }, root)
    return () => ctx.revert()
  }, [])

  if (gone) return null
  return (
    <div className="preloader" ref={root} aria-hidden>
      {Array.from({ length: 5 }).map((_, i) => (
        <div className="preloader__col" key={i} />
      ))}
      <div className="preloader__inner">
        <div className="preloader__word mask">
          {Array.from('Click House').map((c, i) => (
            <span key={i}>{c === ' ' ? ' ' : c}</span>
          ))}
        </div>
        <div className="preloader__meta mask-line">
          <span>Creative digital studio</span>
        </div>
        <div className="preloader__count mask-line">
          <span ref={num}>000</span>
        </div>
        <div className="preloader__bar" ref={bar} />
      </div>
    </div>
  )
}
