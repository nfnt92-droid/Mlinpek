import { useEffect, useRef } from 'react'
import { gsap } from '../lib/gsap'
import { pointer, damp } from '../lib/pointer'
import { isTouch, prefersReduced } from '../lib/env'

type Props = {
  text: string
  className?: string
  /** influence radius as a fraction of viewport width */
  radius?: number
  min?: [number, number] // [wdth, wght] at rest
  max?: [number, number] // [wdth, wght] under the cursor
}

/**
 * Variable-font letters that swell toward the cursor (width + weight).
 * On touch devices a slow travelling wave plays instead, nudged by touch.
 */
export default function ProximityType({ text, className = '', radius = 0.28, min = [72, 380], max = [125, 820] }: Props) {
  const ref = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const root = ref.current
    if (!root || prefersReduced) return
    const chars = Array.from(root.querySelectorAll<HTMLSpanElement>('.px-char'))
    const cur = chars.map(() => 0)
    let visible = true
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting))
    io.observe(root)
    let touchX = -1
    let touchY = -1
    const onTouch = (e: TouchEvent) => {
      touchX = e.touches[0]?.clientX ?? -1
      touchY = e.touches[0]?.clientY ?? -1
    }
    if (isTouch) window.addEventListener('touchmove', onTouch, { passive: true })

    const tick = (t: number, dt: number) => {
      if (!visible) return
      const R = window.innerWidth * radius
      const rects = chars.map((c) => c.getBoundingClientRect())
      let px = pointer.x
      let py = pointer.y
      let live = pointer.active
      if (isTouch) {
        const vw = window.innerWidth
        px = touchX >= 0 ? touchX : vw * (0.5 + 0.55 * Math.sin(t * 0.6))
        py = touchY >= 0 ? touchY : rects[0] ? rects[0].top + rects[0].height / 2 : 0
        live = true
      }
      for (let i = 0; i < chars.length; i++) {
        const r = rects[i]
        const cx = r.left + r.width / 2
        const cy = r.top + r.height / 2
        const dist = Math.hypot((px - cx) * 1, (py - cy) * 1.6)
        const target = live ? Math.max(0, 1 - dist / R) ** 1.6 : 0
        cur[i] += (target - cur[i]) * damp(0.09, dt)
        const k = cur[i]
        const w = min[0] + (max[0] - min[0]) * k
        const g = min[1] + (max[1] - min[1]) * k
        chars[i].style.fontVariationSettings = `'wdth' ${w.toFixed(1)}, 'wght' ${g.toFixed(0)}`
      }
    }
    gsap.ticker.add(tick)
    return () => {
      gsap.ticker.remove(tick)
      io.disconnect()
      window.removeEventListener('touchmove', onTouch)
    }
  }, [text, radius, min[0], min[1], max[0], max[1]])

  return (
    <span className={`px-type ${className}`} ref={ref} aria-label={text}>
      {text.split(' ').map((word, wi, arr) => (
        <span className="px-word" key={wi} aria-hidden>
          {Array.from(word).map((ch, ci) => (
            <span className="px-char-mask" key={ci}>
              <span className="px-char" style={{ fontVariationSettings: `'wdth' ${min[0]}, 'wght' ${min[1]}` }}>
                {ch}
              </span>
            </span>
          ))}
          {wi < arr.length - 1 && <span className="px-space">&nbsp;</span>}
        </span>
      ))}
    </span>
  )
}
