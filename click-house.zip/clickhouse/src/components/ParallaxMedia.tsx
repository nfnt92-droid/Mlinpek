import { useRef, type ReactNode } from 'react'
import { gsap } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'

type Props = {
  children: ReactNode
  className?: string
  /** how far the inner layer travels (fraction of height) */
  depth?: number
  reveal?: 'up' | 'down' | 'center' | 'none'
}

/** Clip-path reveal on entry + inner layer counter-scroll parallax. */
export default function ParallaxMedia({ children, className = '', depth = 0.12, reveal = 'up' }: Props) {
  const ref = useRef<HTMLDivElement>(null)
  useGsap(
    () => {
      const el = ref.current!
      const inner = el.querySelector('.pmedia__inner')
      gsap.fromTo(inner, { yPercent: -depth * 100 }, { yPercent: depth * 100, ease: 'none', scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true } })
      if (reveal !== 'none') {
        const from = reveal === 'up' ? 'inset(100% 0% 0% 0%)' : reveal === 'down' ? 'inset(0% 0% 100% 0%)' : 'inset(20% 20% 20% 20%)'
        gsap.fromTo(el, { clipPath: from }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.6, ease: 'ch.out', scrollTrigger: { trigger: el, start: 'top 90%' } })
        gsap.fromTo(el.querySelector('.pmedia__scale'), { scale: 1.35 }, { scale: 1, duration: 2, ease: 'ch.out', scrollTrigger: { trigger: el, start: 'top 90%' } })
      }
    },
    ref,
  )
  return (
    <div className={`pmedia ${className}`} ref={ref}>
      <div className="pmedia__scale">
        <div className="pmedia__inner" style={{ top: `${-depth * 100}%`, bottom: `${-depth * 100}%` }}>
          {children}
        </div>
      </div>
    </div>
  )
}
