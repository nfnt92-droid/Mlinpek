import { useEffect, useRef, useState } from 'react'
import { gsap } from '../lib/gsap'
import { pointer, damp } from '../lib/pointer'
import { asset, isTouch } from '../lib/env'
import { TLink } from './TransitionProvider'

export type HoverItem = { title: string; meta: string; tags?: string; image: string; to?: string; index?: string }

/**
 * Rows with a floating image that trails the cursor, tilts with velocity and
 * wipes between rows. On touch: inline thumbnails instead.
 */
export default function HoverList({ items, large, follow = true }: { items: HoverItem[]; large?: boolean; follow?: boolean }) {
  const showFloat = follow && !isTouch
  const wrap = useRef<HTMLDivElement>(null)
  const float = useRef<HTMLDivElement>(null)
  const [active, setActive] = useState(-1)
  const prev = useRef(-1)

  useEffect(() => {
    if (!showFloat) return
    const f = float.current!
    const p = { x: pointer.x, y: pointer.y, rot: 0, s: 0 }
    const st = { scale: 0 }
    const tick = (_t: number, dt: number) => {
      p.x += (pointer.x - p.x) * damp(0.1, dt)
      p.y += (pointer.y - p.y) * damp(0.1, dt)
      p.rot += (gsap.utils.clamp(-14, 14, pointer.vx * 0.6) - p.rot) * damp(0.08, dt)
      f.style.transform = `translate3d(${p.x}px, ${p.y}px, 0) translate(-50%, -50%) rotate(${p.rot}deg) scale(${st.scale})`
    }
    gsap.ticker.add(tick)
    const w = wrap.current!
    const enter = () => gsap.to(st, { scale: 1, duration: 0.7, ease: 'ch.out' })
    const leave = () => {
      gsap.to(st, { scale: 0, duration: 0.5, ease: 'ch.in' })
      setActive(-1)
    }
    w.addEventListener('pointerenter', enter)
    w.addEventListener('pointerleave', leave)
    return () => {
      gsap.ticker.remove(tick)
      w.removeEventListener('pointerenter', enter)
      w.removeEventListener('pointerleave', leave)
    }
  }, [showFloat])

  useEffect(() => {
    if (!showFloat || active < 0) return
    const imgs = float.current!.querySelectorAll<HTMLElement>('.hover-float__img')
    const down = active > prev.current
    imgs.forEach((im, i) => {
      if (i === active) {
        gsap.set(im, { zIndex: 2 })
        gsap.fromTo(im, { clipPath: down ? 'inset(100% 0% 0% 0%)' : 'inset(0% 0% 100% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 0.7, ease: 'ch.out', overwrite: true })
        gsap.fromTo(im.firstElementChild, { scale: 1.3, yPercent: down ? 10 : -10 }, { scale: 1, yPercent: 0, duration: 0.9, ease: 'ch.out', overwrite: true })
      } else gsap.set(im, { zIndex: i === prev.current ? 1 : 0 })
    })
    prev.current = active
  }, [active, showFloat])

  return (
    <div className={`hover-list ${large ? 'hover-list--large' : ''}`} ref={wrap}>
      {items.map((it, i) => {
        const inner = (
          <>
            <span className="hover-list__fill" />
            <span className="hover-list__index">{it.index ?? String(i + 1).padStart(2, '0')}</span>
            <span className="hover-list__title">
              <span className="hover-list__title-a">{it.title}</span>
              <span className="hover-list__title-b" aria-hidden>
                {it.title}
              </span>
            </span>
            {it.tags && <span className="hover-list__tags">{it.tags}</span>}
            <span className="hover-list__meta">{it.meta}</span>
            {isTouch && follow && <img className="hover-list__thumb" src={asset(`${it.image}-sm.webp`)} alt="" />}
          </>
        )
        const common = {
          className: `hover-list__row ${active === i ? 'is-active' : ''} ${active >= 0 && active !== i ? 'is-dim' : ''}`,
          onPointerEnter: () => setActive(i),
        }
        return it.to ? (
          <TLink key={i} to={it.to} label={it.title} {...common}>
            {inner}
          </TLink>
        ) : (
          <div key={i} {...common}>
            {inner}
          </div>
        )
      })}
      {showFloat && (
        <div className="hover-float" ref={float} aria-hidden>
          {items.map((it, i) => (
            <div className="hover-float__img" key={i}>
              <img src={asset(`${it.image}-sm.webp`)} alt="" />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
