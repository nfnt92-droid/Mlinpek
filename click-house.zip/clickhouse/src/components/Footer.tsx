import { useRef } from 'react'
import { gsap } from '../lib/gsap'
import { useGsap } from '../lib/useGsap'
import { scrollTo } from '../lib/scroll'
import Magnetic from './Magnetic'
import RollText from './RollText'
import Clock from './Clock'
import ProximityType from './ProximityType'
import { TLink } from './TransitionProvider'

export default function Footer() {
  const ref = useRef<HTMLElement>(null)

  useGsap(
    () => {
      // footer slides out from underneath the page
      gsap.fromTo(
        '.footer__inner',
        { yPercent: -45 },
        { yPercent: 0, ease: 'none', scrollTrigger: { trigger: ref.current, start: 'top bottom', end: 'bottom bottom', scrub: true } },
      )
      gsap.fromTo(
        '.footer__cta-btn',
        { scale: 0.4, rotate: -30 },
        { scale: 1, rotate: 0, ease: 'none', scrollTrigger: { trigger: ref.current, start: 'top 80%', end: 'bottom bottom', scrub: 1 } },
      )
    },
    ref,
  )

  return (
    <footer className="footer" ref={ref}>
      <div className="footer__inner">
        <div className="footer__top">
          <p className="eyebrow">(Next step)</p>
          <h2 className="footer__title">
            <ProximityType text="Let's make it" min={[80, 300]} max={[125, 800]} radius={0.22} />
            <span className="footer__title-line">
              <em className="serif">click.</em>
              <Magnetic strength={0.5} innerStrength={0.25} padding={60} className="footer__cta-wrap">
                <TLink to="/contact" label="Contact" className="footer__cta-btn" data-cursor="hide">
                  <span>Start a<br />project</span>
                </TLink>
              </Magnetic>
            </span>
          </h2>
        </div>
        <div className="footer__grid">
          <div>
            <p className="eyebrow">New business</p>
            <Magnetic strength={0.15}>
              <a className="footer__mail" href="mailto:hello@clickhouse.studio" data-cursor="link">
                hello@clickhouse.studio
              </a>
            </Magnetic>
          </div>
          <div>
            <p className="eyebrow">Social</p>
            <ul className="footer__list">
              {['Instagram', 'Behance', 'LinkedIn', 'Dribbble'].map((s) => (
                <li key={s}>
                  <a href="#" data-cursor="link">
                    <RollText text={s} />
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="eyebrow">Sitemap</p>
            <ul className="footer__list">
              {[
                ['/', 'Home'],
                ['/work', 'Work'],
                ['/studio', 'Studio'],
                ['/contact', 'Contact'],
              ].map(([to, l]) => (
                <li key={to}>
                  <TLink to={to} label={l} data-cursor="link">
                    <RollText text={l} />
                  </TLink>
                </li>
              ))}
            </ul>
          </div>
          <div className="footer__right">
            <p className="eyebrow">Local time</p>
            <Clock />
            <Magnetic strength={0.4}>
              <button className="footer__top-btn" onClick={() => scrollTo(0, { duration: 2 })} data-cursor="stick">
                Back to top ↑
              </button>
            </Magnetic>
          </div>
        </div>
        <div className="footer__bottom">
          <span>© {new Date().getFullYear()} Click House</span>
          <span>Designed around movement</span>
        </div>
      </div>
    </footer>
  )
}
