import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react'
import { FluidImage } from '../gl/FluidImage'
import { asset, isTouch, prefersReduced } from '../lib/env'

export type GLImageHandle = { setHover: (v: number) => void; setZoom: (v: number) => void }

type Props = {
  src: string // without extension, e.g. img/halcyon
  alt: string
  mode?: 'hover' | 'reel'
  className?: string
  small?: boolean
  alignTop?: boolean
}

/** Real <img> underneath (SEO, fallback); WebGL canvas on top when available. */
const GLImage = forwardRef<GLImageHandle, Props>(function GLImage({ src, alt, mode = 'hover', className = '', small, alignTop }, ref) {
  const host = useRef<HTMLDivElement>(null)
  const canvas = useRef<HTMLCanvasElement>(null)
  const inst = useRef<FluidImage | null>(null)
  const file = asset(`${src}${small ? '-sm' : ''}.webp`)

  useImperativeHandle(ref, () => ({
    setHover: (v) => inst.current?.setHover(v),
    setZoom: (v) => inst.current?.setZoom(v),
  }))

  useEffect(() => {
    if (prefersReduced || !FluidImage.supported()) return
    if (isTouch && mode === 'hover') return // static images on touch — battery first
    try {
      inst.current = new FluidImage(canvas.current!, host.current!, file, { mode, alignTop })
    } catch {
      /* fall back to <img> */
    }
    return () => {
      inst.current?.destroy()
      inst.current = null
    }
  }, [file, mode, alignTop])

  return (
    <div className={`gl-image ${alignTop ? 'gl-image--top' : ''} ${className}`} ref={host}>
      <img src={file} alt={alt} draggable={false} decoding="async" />
      <canvas ref={canvas} aria-hidden />
    </div>
  )
})

export default GLImage
