import { useEffect, useState } from 'react'

const fmt = () =>
  new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Sarajevo' }).format(new Date())

export default function Clock() {
  const [t, setT] = useState(fmt)
  useEffect(() => {
    const id = setInterval(() => setT(fmt()), 10_000)
    return () => clearInterval(id)
  }, [])
  const [h, m] = t.split(':')
  return (
    <span className="clock">
      {h}
      <span className="clock__colon">:</span>
      {m} CET
    </span>
  )
}
