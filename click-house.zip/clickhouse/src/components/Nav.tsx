import { useEffect, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { gsap } from '../lib/gsap'
import { getLenis, startScroll, stopScroll } from '../lib/scroll'
import { onPageEnter } from '../lib/transition'
import { TLink, useTransitionNav } from './TransitionProvider'
import Magnetic from './Magnetic'
import RollText from './RollText'
import Clock from './Clock'

const LINKS = [
  { to: '/work', label: 'Work' },
  { to: '/studio', label: 'Studio' },
  { to: '/contact', label: 'Contact' },
]

export default function Nav() {
  const ref = useRef<HTMLElement>(null)
  const menu = useRef<HTMLDivElement>(null)
  const [open, setOpen] = useState(false)
  const loc = useLocation()
  const { go } = useTransitionNav()
  const tl = useRef<gsap.core.Timeline | null>(null)

  // intro + hide on scroll down / show on scroll up
  useEffect(() => {
    const el = ref.current!
    gsap.set(el.querySelectorAll('.nav__item'), { yPercent: -120 })
    const off = onPageEnter(() => {
      gsap.to(el.querySelectorAll('.nav__item'), { yPercent: 0, duration: 1.1, stagger: 0.05, delay: 0.2, overwrite: true })
    })
    let hidden = false
    const lenis = getLenis()
    const onScroll = () => {
      const y = lenis?.scroll ?? window.scrollY
      const dir = lenis?.direction ?? 1
      const shouldHide = y > 140 && dir === 1
      if (shouldHide !== hidden) {
        hidden = shouldHide
        gsap.to(el, { yPercent: hidden ? -120 : 0, duration: 0.7, ease: hidden ? 'ch.in' : 'ch.out' })
      }
    }
    lenis?.on('scroll', onScroll)
    return () => {
      off()
      lenis?.off('scroll', onScroll)
    }
  }, [])

  // fullscreen menu timeline
  useEffect(() => {
    const m = menu.current!
    tl.current = gsap
      .timeline({ paused: true })
      .set(m, { visibility: 'visible' })
      .fromTo(m, { clipPath: 'inset(0% 0% 100% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 0.9, ease: 'ch.inOut' })
      .from(m.querySelectorAll('.menu__link span'), { yPercent: 120, rotate: 4, duration: 1, stagger: 0.07 }, 0.35)
      .from(m.querySelectorAll('.menu__foot > *'), { opacity: 0, y: 20, duration: 0.8, stagger: 0.05 }, 0.55)
    return () => {
      tl.current?.kill()
    }
  }, [])

  useEffect(() => {
    if (!tl.current) return
    if (open) {
      stopScroll()
      tl.current.timeScale(1).play()
    } else {
      startScroll()
      tl.current.timeScale(1.6).reverse()
    }
  }, [open])

  useEffect(() => setOpen(false), [loc.pathname])

  const navTo = (to: string) => {
    if (open) {
      setOpen(false)
      setTimeout(() => go(to), 500)
    } else go(to)
  }

  return (
    <>
      <header className="nav" ref={ref}>
        <div className="nav__item nav__logo">
          <Magnetic strength={0.25} innerStrength={0.12}>
            <TLink to="/" label="Home" data-cursor="stick" className="logo">
              <span className="logo__dot" />
              <span>Click House</span>
            </TLink>
          </Magnetic>
        </div>
        <div className="nav__item nav__clock">
          <span className="nav__muted">Local</span> <Clock />
        </div>
        <nav className="nav__item nav__links" aria-label="Primary">
          {LINKS.map((l) => (
            <Magnetic key={l.to} strength={0.3} innerStrength={0.15}>
              <a
                href={l.to}
                data-cursor="stick"
                className={`nav__link ${loc.pathname.startsWith(l.to) ? 'is-active' : ''}`}
                onClick={(e) => {
                  e.preventDefault()
                  navTo(l.to)
                }}
              >
                <RollText text={l.label} />
              </a>
            </Magnetic>
          ))}
        </nav>
        <div className="nav__item nav__burger">
          <Magnetic strength={0.4}>
            <button className={`burger ${open ? 'is-open' : ''}`} onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label="Menu" data-cursor="stick">
              <span />
              <span />
            </button>
          </Magnetic>
        </div>
      </header>

      <div className="menu" ref={menu} aria-hidden={!open}>
        <nav className="menu__links">
          {[{ to: '/', label: 'Home' }, ...LINKS].map((l, i) => (
            <a
              key={l.to}
              href={l.to}
              className="menu__link"
              onClick={(e) => {
                e.preventDefault()
                navTo(l.to)
              }}
            >
              <span>
                <sup>0{i + 1}</sup>
                {l.label}
              </span>
            </a>
          ))}
        </nav>
        <div className="menu__foot">
          <a href="mailto:hello@clickhouse.studio">hello@clickhouse.studio</a>
          <span>
            <Clock />
          </span>
        </div>
      </div>
    </>
  )
}
