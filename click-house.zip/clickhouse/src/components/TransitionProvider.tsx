import React, { createContext, useCallback, useContext, useEffect, useRef, type ReactNode, type MouseEvent } from 'react'
import { useLocation, useNavigate, Link, type LinkProps } from 'react-router-dom'
import { gsap, ScrollTrigger } from '../lib/gsap'
import { scrollTo, startScroll, stopScroll } from '../lib/scroll'
import { emitPageEnter, hasEnteredOnce } from '../lib/transition'
import { prefersReduced } from '../lib/env'

type Ctx = { go: (to: string, label?: string) => void }
const TransitionCtx = createContext<Ctx>({ go: () => {} })
export const useTransitionNav = () => useContext(TransitionCtx)

const COLS = 5

const labelFor = (path: string) => {
  if (path === '/' || path === '') return 'Home'
  if (path.startsWith('/work/')) return path.split('/')[2].replace(/-/g, ' ')
  return path.replace('/', '')
}

/** Column curtain transition. Covers → swaps route → resets scroll → reveals. */
export function TransitionProvider({ children }: { children: ReactNode }) {
  const navigate = useNavigate()
  const location = useLocation()
  const curtain = useRef<HTMLDivElement>(null)
  const labelRef = useRef<HTMLSpanElement>(null)
  const busy = useRef(false)
  const internal = useRef(false)

  const reveal = useCallback(() => {
    const cols = curtain.current!.querySelectorAll('.curtain__col')
    const tl = gsap.timeline({
      onComplete: () => {
        curtain.current!.style.pointerEvents = 'none'
        busy.current = false
      },
    })
    tl.to(labelRef.current, { yPercent: -110, duration: 0.6, ease: 'ch.in' })
      .add(() => emitPageEnter(), 0.25)
      .to(cols, { scaleY: 0, transformOrigin: '50% 0%', duration: 0.9, stagger: { each: 0.06, from: 'end' }, ease: 'ch.inOut' }, 0.15)
  }, [])

  const go = useCallback(
    (to: string, label?: string) => {
      if (busy.current) return
      if (to === location.pathname) {
        scrollTo(0)
        return
      }
      busy.current = true
      internal.current = true
      stopScroll()
      const cols = curtain.current!.querySelectorAll('.curtain__col')
      labelRef.current!.textContent = label ?? labelFor(to)
      curtain.current!.style.pointerEvents = 'auto'
      if (prefersReduced) {
        navigate(to)
        return
      }
      gsap
        .timeline({
          onComplete: () => {
            navigate(to)
          },
        })
        .set(labelRef.current, { yPercent: 110 })
        .fromTo(cols, { scaleY: 0 }, { scaleY: 1, transformOrigin: '50% 100%', duration: 0.8, stagger: 0.06, ease: 'ch.inOut' })
        .to(labelRef.current, { yPercent: 0, duration: 0.7, ease: 'ch.out' }, 0.45)
    },
    [location.pathname, navigate],
  )

  useEffect(() => {
    gsap.set(labelRef.current, { yPercent: 110, visibility: 'visible' })
  }, [])

  // After the route actually changes
  useEffect(() => {
    if (!hasEnteredOnce()) return // first load handled by the preloader
    scrollTo(0, { immediate: true })
    const wasInternal = internal.current
    internal.current = false
    // two frames → new page has mounted + laid out
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        ScrollTrigger.refresh()
        startScroll()
        if (wasInternal && !prefersReduced) {
          gsap.delayedCall(0.15, reveal)
        } else {
          busy.current = false
          curtain.current!.style.pointerEvents = 'none'
          gsap.set(curtain.current!.querySelectorAll('.curtain__col'), { scaleY: 0 })
          emitPageEnter()
        }
      }),
    )
  }, [location.pathname, reveal])

  return (
    <TransitionCtx.Provider value={{ go }}>
      {children}
      <div className="curtain" ref={curtain} aria-hidden>
        {Array.from({ length: COLS }).map((_, i) => (
          <div className="curtain__col" key={i} />
        ))}
        <div className="curtain__label">
          <span className="curtain__mask">
            <span ref={labelRef}>Home</span>
          </span>
        </div>
      </div>
    </TransitionCtx.Provider>
  )
}

/** Drop-in <Link> that routes through the curtain. */
export function TLink({ to, label, onClick, ...rest }: LinkProps & { to: string; label?: string; ref?: React.Ref<HTMLAnchorElement>; [k: `data-${string}`]: string | number | undefined }) {
  const { go } = useTransitionNav()
  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e)
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return
    e.preventDefault()
    go(to, label)
  }
  return <Link to={to} onClick={handle} {...rest} />
}
