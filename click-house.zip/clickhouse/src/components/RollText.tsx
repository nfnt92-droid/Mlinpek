/** Letters roll up and are replaced by a twin on hover (CSS-driven, staggered). */
export default function RollText({ text }: { text: string }) {
  return (
    <span className="roll" aria-label={text}>
      <span className="roll__row" aria-hidden>
        {Array.from(text).map((c, i) => (
          <span key={i} className="roll__ch" style={{ ['--i' as string]: i }} data-ch={c === ' ' ? ' ' : c}>
            {c === ' ' ? ' ' : c}
          </span>
        ))}
      </span>
    </span>
  )
}
