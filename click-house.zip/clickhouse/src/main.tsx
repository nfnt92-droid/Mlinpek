import { createRoot } from 'react-dom/client'
import { BrowserRouter, HashRouter } from 'react-router-dom'
import '@fontsource-variable/archivo/wdth.css'
import '@fontsource/instrument-serif/400.css'
import '@fontsource/instrument-serif/400-italic.css'
import './styles/global.css'
import './lib/gsap'
import { initScroll } from './lib/scroll'
import { initPointer } from './lib/pointer'
import { isHashRouter } from './lib/env'
import App from './App'

if ('scrollRestoration' in history) history.scrollRestoration = 'manual'
initScroll()
initPointer()

const Router = isHashRouter ? HashRouter : BrowserRouter
createRoot(document.getElementById('root')!).render(
  <Router>
    <App />
  </Router>,
)
