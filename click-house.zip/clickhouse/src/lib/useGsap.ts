import { useLayoutEffect, type DependencyList, type RefObject } from 'react'
import { gsap } from './gsap'

/** Scoped GSAP context that reverts every tween + ScrollTrigger on unmount. */
export function useGsap(fn: (ctx: gsap.Context) => void | (() => void), scope: RefObject<HTMLElement | null>, deps: DependencyList = []) {
  useLayoutEffect(() => {
    let cleanup: void | (() => void)
    const ctx = gsap.context((self) => {
      cleanup = fn(self)
    }, scope.current ?? undefined)
    return () => {
      if (typeof cleanup === 'function') cleanup()
      ctx.revert()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
}
