/** Tiny event bus: pages register intro animations that fire when the curtain lifts. */
type Fn = () => void
const listeners = new Set<Fn>()
let entered = false

export function onPageEnter(fn: Fn) {
  listeners.add(fn)
  return () => listeners.delete(fn)
}
export function emitPageEnter() {
  entered = true
  listeners.forEach((f) => f())
}
export const hasEnteredOnce = () => entered
