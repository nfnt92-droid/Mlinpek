import { gsap } from './gsap'

/**
 * One global pointer model. Raw position + a velocity estimate that decays,
 * so anything (cursor, type, shaders, tilts) can read the same "physics".
 */
export const pointer = {
  x: typeof window !== 'undefined' ? window.innerWidth / 2 : 0,
  y: typeof window !== 'undefined' ? window.innerHeight / 2 : 0,
  vx: 0,
  vy: 0,
  speed: 0,
  // normalised -1..1 from viewport centre
  nx: 0,
  ny: 0,
  active: false,
}

let lastX = pointer.x
let lastY = pointer.y
let started = false

export function initPointer() {
  if (started) return
  started = true
  window.addEventListener(
    'pointermove',
    (e) => {
      pointer.x = e.clientX
      pointer.y = e.clientY
      pointer.active = true
    },
    { passive: true },
  )
  document.addEventListener('pointerleave', () => (pointer.active = false))
  gsap.ticker.add((_t, dt) => {
    const k = Math.min(dt / 16.67, 3)
    const dx = pointer.x - lastX
    const dy = pointer.y - lastY
    pointer.vx += (dx - pointer.vx) * 0.25 * k
    pointer.vy += (dy - pointer.vy) * 0.25 * k
    pointer.speed = Math.hypot(pointer.vx, pointer.vy)
    pointer.nx = (pointer.x / window.innerWidth) * 2 - 1
    pointer.ny = (pointer.y / window.innerHeight) * 2 - 1
    lastX = pointer.x
    lastY = pointer.y
  })
}

/** Frame-rate independent lerp factor. */
export const damp = (factor: number, dt: number) => 1 - Math.pow(1 - factor, dt / 16.67)
