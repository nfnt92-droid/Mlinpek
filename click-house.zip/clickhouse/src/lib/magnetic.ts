import { gsap } from './gsap'
import { pointer } from './pointer'
import { isTouch, prefersReduced } from './env'

type Entry = {
  el: HTMLElement
  inner: HTMLElement | null
  strength: number
  innerStrength: number
  padding: number
  active: boolean
  xTo: gsap.QuickToFunc
  yTo: gsap.QuickToFunc
  ixTo?: gsap.QuickToFunc
  iyTo?: gsap.QuickToFunc
}

const entries = new Set<Entry>()
let running = false
let lx = -1
let ly = -1

function tick() {
  if (lx === pointer.x && ly === pointer.y) return
  lx = pointer.x
  ly = pointer.y
  // read pass
  const reads: [Entry, DOMRect][] = []
  entries.forEach((e) => reads.push([e, e.el.getBoundingClientRect()]))
  // write pass
  for (const [e, r] of reads) {
    // subtract current transform so the field doesn't chase itself
    const tx = (gsap.getProperty(e.el, 'x') as number) || 0
    const ty = (gsap.getProperty(e.el, 'y') as number) || 0
    const cx = r.left - tx + r.width / 2
    const cy = r.top - ty + r.height / 2
    const dx = pointer.x - cx
    const dy = pointer.y - cy
    const inside = Math.abs(dx) < r.width / 2 + e.padding && Math.abs(dy) < r.height / 2 + e.padding
    if (inside) {
      if (!e.active) {
        e.active = true
        e.el.classList.add('is-magnet')
      }
      e.xTo(dx * e.strength)
      e.yTo(dy * e.strength)
      e.ixTo?.(dx * e.innerStrength)
      e.iyTo?.(dy * e.innerStrength)
    } else if (e.active) {
      e.active = false
      e.el.classList.remove('is-magnet')
      // release with a soft elastic settle
      gsap.to(e.el, { x: 0, y: 0, duration: 1.1, ease: 'elastic.out(1, 0.4)', overwrite: true })
      if (e.inner) gsap.to(e.inner, { x: 0, y: 0, duration: 1.1, ease: 'elastic.out(1, 0.4)', overwrite: true })
      e.xTo = gsap.quickTo(e.el, 'x', { duration: 0.6, ease: 'power3.out' })
      e.yTo = gsap.quickTo(e.el, 'y', { duration: 0.6, ease: 'power3.out' })
      if (e.inner) {
        e.ixTo = gsap.quickTo(e.inner, 'x', { duration: 0.6, ease: 'power3.out' })
        e.iyTo = gsap.quickTo(e.inner, 'y', { duration: 0.6, ease: 'power3.out' })
      }
    }
  }
}

export function registerMagnet(el: HTMLElement, opts: { strength?: number; innerStrength?: number; padding?: number } = {}) {
  if (isTouch || prefersReduced) return () => {}
  const inner = el.querySelector<HTMLElement>('[data-magnet-inner]')
  const e: Entry = {
    el,
    inner,
    strength: opts.strength ?? 0.35,
    innerStrength: opts.innerStrength ?? 0.18,
    padding: opts.padding ?? 30,
    active: false,
    xTo: gsap.quickTo(el, 'x', { duration: 0.6, ease: 'power3.out' }),
    yTo: gsap.quickTo(el, 'y', { duration: 0.6, ease: 'power3.out' }),
    ixTo: inner ? gsap.quickTo(inner, 'x', { duration: 0.6, ease: 'power3.out' }) : undefined,
    iyTo: inner ? gsap.quickTo(inner, 'y', { duration: 0.6, ease: 'power3.out' }) : undefined,
  }
  entries.add(e)
  if (!running) {
    running = true
    gsap.ticker.add(tick)
  }
  return () => {
    entries.delete(e)
    gsap.killTweensOf([el, inner].filter(Boolean))
    gsap.set(el, { clearProps: 'transform' })
  }
}
