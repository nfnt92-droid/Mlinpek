import Lenis from 'lenis'
import { gsap, ScrollTrigger } from './gsap'
import { isTouch, prefersReduced } from './env'

let lenis: Lenis | null = null

/** Scroll velocity, smoothed — shared by marquees, skews, etc. */
export const scrollState = { velocity: 0, direction: 1 as 1 | -1, progress: 0 }

export function initScroll() {
  if (lenis) return lenis
  lenis = new Lenis({
    duration: prefersReduced ? 0 : 1.15,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smoothWheel: !prefersReduced,
    // Touch keeps native momentum — it already feels right on phones.
    syncTouch: false,
    wheelMultiplier: 0.9,
  })
  lenis.on('scroll', (l: Lenis) => {
    scrollState.velocity = l.velocity
    scrollState.direction = l.direction === -1 ? -1 : 1
    scrollState.progress = l.progress
    ScrollTrigger.update()
  })
  gsap.ticker.add((t) => lenis!.raf(t * 1000))
  gsap.ticker.lagSmoothing(0)
  if (isTouch) document.documentElement.classList.add('is-touch')
  ;(window as unknown as { __lenis?: Lenis }).__lenis = lenis
  return lenis
}

export const getLenis = () => lenis

export function scrollTo(target: number | string | HTMLElement, opts: { immediate?: boolean; offset?: number; duration?: number } = {}) {
  if (lenis) lenis.scrollTo(target as never, { immediate: opts.immediate, offset: opts.offset, duration: opts.duration, force: true })
  else if (typeof target === 'number') window.scrollTo(0, target)
}

export const stopScroll = () => lenis?.stop()
export const startScroll = () => lenis?.start()
