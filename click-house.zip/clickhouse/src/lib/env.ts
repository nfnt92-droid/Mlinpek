export const isTouch =
  typeof window !== 'undefined' &&
  (window.matchMedia('(hover: none), (pointer: coarse)').matches || 'ontouchstart' in window && navigator.maxTouchPoints > 0 && !window.matchMedia('(hover: hover)').matches)

export const prefersReduced =
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

export const isHashRouter: boolean = __HASH_ROUTER__

export const asset = (p: string) => `${import.meta.env.BASE_URL}${p.replace(/^\//, '')}`
