import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { CustomEase } from 'gsap/CustomEase'

gsap.registerPlugin(ScrollTrigger, SplitText, CustomEase)

// House easing vocabulary — every motion in the site draws from these.
CustomEase.create('ch.out', '0.16, 1, 0.3, 1') // long, confident deceleration
CustomEase.create('ch.inOut', '0.76, 0, 0.24, 1') // curtain / transition moves
CustomEase.create('ch.in', '0.7, 0, 0.84, 0')
CustomEase.create('ch.soft', '0.33, 1, 0.68, 1')

gsap.defaults({ ease: 'ch.out', duration: 1.2 })
ScrollTrigger.config({ ignoreMobileResize: true })

export { gsap, ScrollTrigger, SplitText }
