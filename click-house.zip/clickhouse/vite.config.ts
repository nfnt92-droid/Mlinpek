import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// `--mode preview` builds with relative paths + hash routing so the site
// can be opened from any sub-path (e.g. a hosted preview). Netlify uses the default.
export default defineConfig(({ mode }) => ({
  plugins: [react()],
  base: mode === 'preview' ? './' : '/',
  define: { __HASH_ROUTER__: JSON.stringify(mode === 'preview') },
  build: { target: 'es2020', assetsInlineLimit: 0 },
}))
