"""Procedural, original cover art for Click House case studies.
Smooth mesh-gradient fields + a single graphic gesture per piece."""
import numpy as np
from PIL import Image
import sys, os

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)


def lowfreq(w, h, cells, seed):
    r = np.random.default_rng(seed)
    g = r.random((cells, int(cells * w / h) + 1)).astype(np.float32)
    im = Image.fromarray((g * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
    return np.asarray(im, np.float32) / 255


def grid(w, h):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    return xx / w, yy / h


def blobs(x, y, pts, seed, warp=0.08):
    h, w = x.shape
    wx = (lowfreq(w, h, 4, seed) - 0.5) * warp * 2
    wy = (lowfreq(w, h, 4, seed + 1) - 0.5) * warp * 2
    xs, ys = x + wx, y + wy
    acc = np.zeros(x.shape + (3,), np.float32)
    wsum = np.zeros(x.shape, np.float32)
    for (px, py, r, col) in pts:
        d2 = ((xs - px) ** 2 + (ys - py) ** 2) / (r * r)
        wt = np.exp(-d2)
        acc += wt[..., None] * (np.array(col, np.float32) / 255)
        wsum += wt
    return acc / (wsum[..., None] + 1e-4)


def grain(img, amt, seed):
    n = np.random.default_rng(seed).normal(0, amt, img.shape[:2]).astype(np.float32)[..., None]
    return np.clip(img + n, 0, 1)


def vignette(img, x, y, s):
    d = (x - 0.5) ** 2 + (y - 0.5) ** 2
    return img * (1 - s * d[..., None])


def sm(edge, v, soft=0.002):
    return np.clip((v - edge) / soft + 0.5, 0, 1)


def save(img, name, w):
    im = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    im.save(f"{OUT}/{name}.webp", quality=82, method=6)
    im.resize((w // 2, im.height * (w // 2) // w), Image.LANCZOS).save(f"{OUT}/{name}-sm.webp", quality=80, method=6)
    print(name)


W, H = 1600, 2000
x, y = grid(W, H)

# 1 Halcyon — ember dusk with a thin ring
img = blobs(x, y, [(0.2, 0.15, 0.5, (8, 12, 30)), (0.8, 0.3, 0.45, (66, 92, 145)), (0.4, 0.75, 0.5, (26, 36, 64)), (0.9, 0.9, 0.35, (170, 185, 230)), (0.1, 0.95, 0.3, (6, 8, 20))], 1)
d = np.sqrt((x - 0.5) ** 2 + ((y - 0.48) * 0.8) ** 2)
ring = (sm(0.297, d, 0.0015) - sm(0.303, d, 0.0015))[..., None]
img = img * (1 - ring * 0.85) + np.array([0.9, 0.93, 1.0]) * ring * 0.85
save(grain(vignette(img, x, y, 0.5), 0.035, 1), "halcyon", W)

# 2 Northbound — chrome cold, horizontal slats
img = blobs(x, y, [(0.3, 0.2, 0.45, (210, 225, 232)), (0.7, 0.55, 0.4, (30, 48, 66)), (0.2, 0.8, 0.4, (90, 120, 140)), (0.85, 0.15, 0.3, (12, 18, 26))], 2, 0.12)
slat = (np.sin(y * 3.14 * 60) > 0.92).astype(np.float32)[..., None] * (y > 0.62)[..., None]
img = img * (1 - slat * 0.4)
save(grain(vignette(img, x, y, 0.6), 0.03, 2), "northbound", W)

# 3 Verde — acid green field with a lit vermilion orb
img = blobs(x, y, [(0.2, 0.2, 0.5, (190, 240, 70)), (0.8, 0.8, 0.5, (16, 50, 24)), (0.7, 0.2, 0.35, (60, 140, 50)), (0.2, 0.9, 0.3, (230, 255, 160))], 3)
d = np.sqrt((x - 0.56) ** 2 + ((y - 0.46) * 1.25) ** 2)
orb = sm(-0.24, -d, 0.003)[..., None]
lx = np.clip(1 - np.sqrt((x - 0.48) ** 2 + ((y - 0.38) * 1.25) ** 2) / 0.32, 0, 1)
shade = (np.array([10, 16, 60]) + lx[..., None] ** 1.4 * np.array([120, 150, 220])) / 255
img = img * (1 - orb) + shade * orb
save(grain(vignette(img, x, y, 0.4), 0.035, 3), "verde", W)

# 4 Atelier — warm paper, single folded diagonal
img = blobs(x, y, [(0.2, 0.2, 0.5, (238, 228, 210)), (0.8, 0.7, 0.5, (170, 150, 124)), (0.3, 0.9, 0.4, (110, 90, 70)), (0.9, 0.1, 0.3, (250, 244, 232))], 4, 0.05)
fold = (y > 0.25 + x * 0.6).astype(np.float32)[..., None]
img = img * (1 - fold * 0.18)
save(grain(vignette(img, x, y, 0.35), 0.03, 4), "atelier", W)

# 5 Pulse — violet / magenta waveform
img = blobs(x, y, [(0.2, 0.25, 0.45, (20, 14, 70)), (0.75, 0.4, 0.4, (66, 92, 145)), (0.3, 0.8, 0.45, (6, 6, 22)), (0.85, 0.9, 0.35, (190, 205, 245))], 5, 0.1)
wave = 0.5 + 0.18 * np.sin(x * 3.14 * 6) * np.sin(x * 3.14)
line = np.clip(1 - np.abs(y - wave) / 0.0025, 0, 1)[..., None]
img = img * (1 - line) + np.array([1, 0.95, 0.9]) * line
save(grain(vignette(img, x, y, 0.6), 0.035, 5), "pulse", W)

# 6 Saltworks — blue hour horizon
sky = blobs(x, y, [(0.3, 0.05, 0.5, (236, 214, 198)), (0.8, 0.4, 0.4, (130, 150, 182)), (0.2, 0.5, 0.3, (190, 170, 180))], 6, 0.06)
sea = blobs(x, y, [(0.3, 0.7, 0.4, (30, 60, 92)), (0.8, 0.95, 0.4, (6, 14, 28)), (0.6, 0.62, 0.2, (190, 200, 210))], 7, 0.04)
m = sm(0.58, y, 0.002)[..., None]
img = sky * (1 - m) + sea * m
save(grain(vignette(img, x, y, 0.45), 0.03, 6), "saltworks", W)

# Studio wide
W2, H2 = 2400, 1400
x, y = grid(W2, H2)
img = blobs(x, y, [(0.15, 0.3, 0.4, (14, 15, 18)), (0.6, 0.5, 0.35, (56, 80, 128)), (0.9, 0.2, 0.3, (170, 182, 205)), (0.4, 0.95, 0.35, (30, 33, 40)), (0.95, 0.9, 0.3, (8, 9, 12))], 8, 0.1)
save(grain(vignette(img, x, y, 0.5), 0.03, 7), "studio", W2)
