# Click House — creative digital studio website

React + Vite + TypeScript, GSAP (ScrollTrigger, SplitText, CustomEase), Lenis smooth scroll, raw WebGL shaders. No UI framework; one hand-written stylesheet (`src/styles/global.css`).

## Run
```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build → dist/
```

## Deploy to Netlify
Push to Git and connect the repo, or drag `dist/` into Netlify. `netlify.toml` already sets the build command, SPA redirects and asset caching. The contact form is wired to **Netlify Forms** (form name `project`).

## Interaction system
| Piece | File |
|---|---|
| Two-body cursor (velocity stretch, sticky, "View" states) | `components/Cursor.tsx` |
| Magnetic field (outer + inner parallax, elastic release) | `lib/magnetic.ts`, `components/Magnetic.tsx` |
| Variable-font proximity type (wdth + wght follow cursor; travelling wave on touch) | `components/ProximityType.tsx` |
| WebGL images: cursor lens, velocity smear, chromatic split, idle breathing | `gl/FluidImage.ts`, `components/GLImage.tsx` |
| Pinned hero: inline media window expands to full-bleed reel | `sections/Hero.tsx` |
| Scroll-ink manifesto with growing image pills | `sections/Manifesto.tsx` |
| Depth-staggered work grid, clip reveals, 3D tilt | `sections/SelectedWork.tsx` |
| Scroll-velocity marquees (speed, direction, skew) | `components/Marquee.tsx` |
| Hover list with trailing, velocity-tilted image | `components/HoverList.tsx` |
| Horizontal pinned process (vertical on mobile) | `sections/Process.tsx` |
| Column-curtain page transitions + preloader | `components/TransitionProvider.tsx`, `components/Preloader.tsx` |
| Scroll-to-advance "next project" | `pages/Project.tsx` |

Shared physics: `lib/pointer.ts` (pointer + velocity), `lib/scroll.ts` (Lenis + scroll velocity), house easings in `lib/gsap.ts`.

Touch devices: custom cursor, magnetism and WebGL hover are off; type uses a wave + touch input, the reel keeps its idle shader, and the hover lists show inline thumbnails. `prefers-reduced-motion` is respected.

## Projects (Selected Work + /work)
All project data lives in `src/data/projects.ts`. The homepage shows the four entries with `featured` 1–4, in that order. Each card shows:
- a browser-framed **screenshot** (`preview`, top-left anchored, WebGL hover lens), or a typographic cover if there's no screenshot
- name, industry and services (only the fields you've filled in), plus a **Concept** label when `status: 'concept'`
- **Visit website ↗**: the whole card and the link open `url` in a new tab
- **Explore live ⟷** (desktop, when `embed: true`): loads the real site into the frame, scaled and scrollable. It's only requested on click, so the homepage stays light. If the site hasn't loaded after 9 s, a "visit website" link replaces it.

Embedding status (checked 17 Nov 2026): Mlinpek, Kalvarija Kop and K.A.D.G allow it. Tecta sends `X-Frame-Options: SAMEORIGIN`, so `embed: false` and screenshot only. The claude.ai preview link blocks all embedded sites, so test "Explore live" on the Netlify deploy.

Screenshots live in `public/img/work/`: `<slug>.webp` (homepage card), `<slug>-desktop.webp` (case cover + gallery), `<slug>-mobile.webp` (mobile cover + gallery), `<slug>-section.webp` (inner section, gallery). Replace them any time with your own `.webp` files: portrait cards (Kalvarija Kop, Tecta) use phone-width captures, wide cards (Mlinpek, K.A.D.G) use desktop captures.

## Hero photograph
`public/img/hero.webp`: black-and-white eye close-up by **Raphael Brasileiro** on Pexels (pexels.com/photo/2558823), free for commercial use under the Pexels license (attribution appreciated, not required). Cropped so the eye is the exact centre and given a cool charcoal tone. To use your own photo, replace `hero.webp`/`hero-sm.webp` and update `IMG_W`, `IMG_H` and `EYE_W` in `src/sections/Hero.tsx` if the subject size differs.

## Process photographs
`public/img/process/`, all from Pexels (free for commercial use under the Pexels license), cropped to 4:3 and given the site's charcoal-to-steel-blue tone:
- Listen: listening to a client in a meeting, Pavel Danilyuk (pexels.com/photo/6764204)
- Shape: monochrome 3D digital form, Steve A Johnson (pexels.com/photo/29636885)
- Move: long-exposure dancer (pexels.com/photo/1231258)
- Launch: rocket launch long exposure, SpaceX (pexels.com/photo/23764)

## Replace before launch
- `public/img/*` — original procedural artwork made for this build. Swap in real project imagery (same file names, or edit `src/data/projects.ts`).
- `src/data/projects.ts`: fill in each project's `services` (left blank, not invented).
- `hello@clickhouse.studio`, social links (`#`), and the CET clock (timezone in `components/Clock.tsx`).
